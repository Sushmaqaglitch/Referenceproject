package StepDefinitionFeatures;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PageObjectBase {
    final By primaryWell = By.xpath(".//hp5-well-primary//*[contains(@class,'well-primary')]");
    final By username = By.id("username");
    final By password = By.id("password");
    final By signInBtn = By.id("submit-button");
    private final WebDriverWait wait;
    public WebDriver driver;

    public PageObjectBase() {
        super();
        try {
            if (driver == null) {
                driver = Hooks.createAndGetDriver();
            }
        } catch (Exception e) {
            System.out.println("DEBUG DriverException::====================");
            e.printStackTrace();
            System.out.println("DEBUG DriverException::====================");
            Assert.fail("Exception occurred instantiating PageObjectBase.driver [" + e.getMessage() + "]");
        }
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(40));
    }


    By contentText(String content) {
        return By.xpath("//*[contains(text(),'" + content + "')]");
    }

    public boolean contentTextCount(String content) {
        int count;
        List<WebElement> contentTextElement = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(contentText(content)));
        count = contentTextElement.size();
        return count > 0;
    }

    public int primaryWellCount() {
        int count;
        List<WebElement> primaryWellElement = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(primaryWell));
        count = primaryWellElement.size();
        return count;
    }

    public void waitForPageLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                try {
                    return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
                } catch (UnsupportedCommandException e) {
                    return false;
                }
            }
        };
        WebDriverWait ninetySecond = new WebDriverWait(this.driver, Duration.ofSeconds(90));
        ninetySecond.until(pageLoadCondition);
    }

    public void waitForJavascriptToLoad(int maxWaitMillis, int pollDelimiter) {
        waitForPageLoad();
        double startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() < startTime + maxWaitMillis) {
            try {
                String prevState = driver.getPageSource();
                Thread.sleep(pollDelimiter);
                if (prevState.equals(driver.getPageSource())) {
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void waitForPageToLoad(WebDriver driver, int maxWaitMillis, int pollDelimiter) {
        waitForJavascriptToLoad(maxWaitMillis, pollDelimiter);
    }

    public String getPageTitle() {
        waitForPageToLoad(driver, 10000, 500);
        return driver.getTitle();
    }

    public String getCurrentUrl() {
        waitForPageToLoad(driver, 10000, 500);
        return driver.getCurrentUrl();
    }

    public void validateLandingPageOnNewTab(String pageTitle, String landingPage) throws InterruptedException {
        // get window handlers as a list
        List<String> browserTabs = new ArrayList<String>(driver.getWindowHandles());
        // switch to a new tab
        driver.switchTo().window(browserTabs.get(1));
        waitForPageLoad();
        // validate page title and landing page url
        Assert.assertTrue(getPageTitle().contains(pageTitle));
        Assert.assertTrue(getCurrentUrl().contains(landingPage));
        // close the tab
        driver.close();
        // switch to default tab
        driver.switchTo().window(browserTabs.get(0));
    }

    public void closeCurrentWindowOfheBrowser() {
        driver.close();
    }

    public void switchBackToPreviousTab() {
        Actions action = new Actions(driver);
        action.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys(Keys.TAB).build().perform();
        driver.switchTo().defaultContent();
    }

    public void loginToProdAuthor(String usernameText, String passwordText) {
        waitForPageToLoad(driver, 10000, 600);
        WebElement usernameElement = wait.until(ExpectedConditions.presenceOfElementLocated(username));
        usernameElement.sendKeys(usernameText);
        WebElement passwordElement = wait.until(ExpectedConditions.presenceOfElementLocated(password));
        passwordElement.sendKeys(passwordText);
        WebElement signInBtnElement = wait.until(ExpectedConditions.elementToBeClickable(signInBtn));
        signInBtnElement.click();
    }

    public void click(By element) {
        waitForPageToLoad(driver, 5000, 400);
        WebElement webElement = wait.until(ExpectedConditions.elementToBeClickable(element));
        scrollElementIntoView(webElement);
        webElement.click();
    }

    public void isDisplayed(By element) {
        waitForPageToLoad(driver, 5000, 400);
        WebElement webElement = wait.until(ExpectedConditions.visibilityOfElementLocated(element));
        scrollElementIntoView(webElement);
        webElement.isDisplayed();
    }

    public void scroll() throws InterruptedException {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-300)");
        Thread.sleep(2000);
    }

    public void scrollElementIntoView(WebElement element) {
        String scrollScript = "window.scrollBy(0, arguments[0].getBoundingClientRect().top - (window.innerHeight/2));";
        ((JavascriptExecutor) driver).executeScript(scrollScript, element);
        try {
            Thread.sleep(100);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void enterText(By element, String searchText) {
        waitForPageToLoad(driver, 10000, 600);
        WebElement webElement = wait.until(ExpectedConditions.elementToBeClickable(element));
        webElement.sendKeys(searchText);
    }

    protected String getRandomString() {
        String RANDOMCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder random = new StringBuilder();
        Random rnd = new Random();
        while (random.length() < 18) {
            int index = (int) (rnd.nextFloat() * RANDOMCHARS.length());
            random.append(RANDOMCHARS.charAt(index));
        }
        String randomStr = random.toString();
        return randomStr;
    }

    protected String getRandomNumber() {
        String RANDOMNUMS = "1234567890";
        StringBuilder random = new StringBuilder();
        Random rnd = new Random();
        while (random.length() < 10) {
            int index = (int) (rnd.nextFloat() * RANDOMNUMS.length());
            random.append(RANDOMNUMS.charAt(index));
        }
        String randomStr = random.toString();
        return randomStr;
    }

    public boolean selectDropdownValueFromList(By element, String dropdownText) {
        Select dropdown = new Select(
                wait.until(ExpectedConditions.presenceOfElementLocated(element)));
        dropdown.selectByVisibleText(dropdownText);
        return true;
    }

}
