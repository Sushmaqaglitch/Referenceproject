package Pages;

import StepDefinitionFeatures.PageObjectBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GlobalNavPage extends PageObjectBase {
    final By globalNavHealthPartnersDropDown = By.className("global-nav-menu");

    private final WebDriver driver;
    private final WebDriverWait wait;

    public GlobalNavPage(WebDriver driver) {
        super();
        this.driver = driver;
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(90));
    }

    By anchorLinkText(String text) {
        return By.xpath("//a[contains(text(),'" + text + "')]");
    }

    By globalNavListItemBtn(String btnText) {
        return By.xpath(".//*[contains(@class,'global-nav-list-item')]//*[contains(text(),'" + btnText + "')]");
    }

    public void clickGlobalNavHealthPartnersDropDown() {
        waitForPageToLoad(driver, 10000, 500);
        WebElement globalNavHealthPartnersDropdownElement = wait.until(ExpectedConditions.elementToBeClickable(globalNavHealthPartnersDropDown));
        globalNavHealthPartnersDropdownElement.click();
    }

    public void clickGlobalNavMenu(String linkText) {
        waitForPageToLoad(driver, 10000, 500);
        WebElement globalNavMenuElement = wait.until(ExpectedConditions.elementToBeClickable(anchorLinkText(linkText)));
        globalNavMenuElement.click();
    }

    public void clickGlobalNavListItemBtn(String btnText) {
        waitForPageToLoad(driver, 10000, 500);
        WebElement globalNavListBtnElement = wait.until(ExpectedConditions.elementToBeClickable(globalNavListItemBtn(btnText)));
        globalNavListBtnElement.click();
    }
}
