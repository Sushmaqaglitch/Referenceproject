package Pages;

import StepDefinitionFeatures.PageObjectBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SiteNavPage extends PageObjectBase {
    final By searchBox = By.id("search-box");

    private final WebDriver driver;
    private final WebDriverWait wait;

    public SiteNavPage(WebDriver driver) {
        super();
        this.driver = driver;
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(90));
    }

    public void enterSearchText(String searchText) {
        waitForPageToLoad(driver, 10000, 600);
        WebElement searchTextElement = wait.until(ExpectedConditions.elementToBeClickable(searchBox));
        searchTextElement.sendKeys(searchText);
    }
}
