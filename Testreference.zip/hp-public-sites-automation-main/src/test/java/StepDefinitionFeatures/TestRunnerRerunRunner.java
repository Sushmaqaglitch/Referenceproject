package StepDefinitionFeatures;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(
        features = {"@targetrerun/cucumber-reports/runnerrerun.txt"},
        monochrome = true,
        plugin = {
                "pretty",
                "html:targetrerunrunner/cucumber-reports/report.html",
                "json:targetrerunrunner/cucumber-reports/cucumber.json"
        }
)

public class TestRunnerRerunRunner extends AbstractTestNGCucumberTests {
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
