package Config;


import lombok.extern.slf4j.Slf4j;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

@Slf4j
public class Retry implements IRetryAnalyzer {

    private static final int maxCount = 2;
    private int retryCount = 0;

    public String getResultStatusName(int status) {
        String resultName = null;
        if (status == 1)
            resultName = "SUCCESS";
        if (status == 2)
            resultName = "FAILURE";
        if (status == 3)
            resultName = "SKIP";
        return resultName;
    }

//    @Override
//    public boolean retry(ITestResult iTestResult) {
//        if (!iTestResult.isSuccess()) {
//            if (retryCount < maxCount) {
//                log.info("Retrying test " + iTestResult.getName() + " with status " + "'" + getResultStatusName(iTestResult.getStatus()) + "'" + " for the " + (retryCount + 1) + " time(s).");
//                retryCount++;
//                return true;
//            }
//        } return false;
//    }
////    public boolean retry(ITestResult result) {
////        if (retryCount < maxCount) {
////            System.out.println("retry count is " + retryCount);
////            System.out.println("max count is " + maxCount);
////            retryCount++;
////            return true;
////        }
////        System.out.println("retry is done");
////        return false;
////
////    }

    /**
     * Below method returns 'true' if the test method has to be retried else
     * 'false' and it takes the 'Result' as parameter of the test method that
     * just ran
     *
     * @see org.testng.IRetryAnalyzer#retry(org.testng.ITestResult)
     */

    @Override
    public boolean retry(ITestResult result) {
        if (retryCount < maxCount) {
            retryCount++;
            return true;
        }
        if (!result.isSuccess()) {
            int maxRetryCount = 1;
            if (retryCount < maxRetryCount) {
                log.info("Retrying test " + result.getName() + " with status " + "'" + getResultStatusName(result.getStatus()) + "'" + " for the " + (retryCount + 1) + " time(s).");
                result.setStatus(ITestResult.SKIP);
                retryCount++;
                return true;
            } else {
                result.setStatus(ITestResult.FAILURE);  //If maxCount reached,test marked as failed
            }
        } else {
            result.setStatus(ITestResult.SUCCESS);      //If test passes, TestNG marks it as passed
        }
        return false;
    }
}
