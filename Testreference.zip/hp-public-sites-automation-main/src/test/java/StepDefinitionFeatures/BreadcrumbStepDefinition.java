package StepDefinitionFeatures;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class BreadcrumbStepDefinition extends PageObjectBase {
    public final ThreadLocal<WebDriver> driver = Hooks.driver;
    final ObjectRepository objectRepository = new ObjectRepository();

    @Then("^I validate \"([^\"]*)\" breadcrumb text$")
    public void validateBreadcrumbText(String breadcrumbText) {
        isDisplayed(objectRepository.breadcrumbText(breadcrumbText));
    }

    @Then("^I validate \"([^\"]*)\" breadcrumb link$")
    public void validateBreadcrumbLink(String linkText) {
        isDisplayed(objectRepository.breadcrumbLink(linkText));
    }

    @When("^I click on \"([^\"]*)\" breadcrumb link$")
    public void clickBreadcrumbLink(String linkText) {
        click(objectRepository.breadcrumbLink(linkText));
    }

}
