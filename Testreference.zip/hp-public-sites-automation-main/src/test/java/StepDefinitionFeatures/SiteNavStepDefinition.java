package StepDefinitionFeatures;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class SiteNavStepDefinition extends PageObjectBase {
    public ThreadLocal<WebDriver> driver = Hooks.driver;
    ObjectRepository objectRepository = new ObjectRepository();

    @When("^I click on \"([^\"]*)\" nav link for \"([^\"]*)\" category under \"([^\"]*)\" nav title$")
    public void clickNavLink(String navLink, String category, String navTitle) {
        click(objectRepository.navTitle(navTitle));
        click(objectRepository.navLinkCategory(category, navLink));
    }

    @When("^I click on \"([^\"]*)\" hyper link under \"([^\"]*)\" nav title$")
    public void clickHyperLink(String hyperLink, String navTitle) {
        click(objectRepository.navTitle(navTitle));
        click(objectRepository.navLinkText(navTitle, hyperLink));
    }

    @When("^I click on \"([^\"]*)\" span hyper link under \"([^\"]*)\" nav title$")
    public void clickSpanHyperLink(String hyperLink, String navTitle) {
        click(objectRepository.navTitle(navTitle));
        click(objectRepository.navSpanLinkText(navTitle, hyperLink));
    }

    @When("^I click on \"([^\"]*)\" nav link under \"([^\"]*)\" nav title$")
    public void clickSiteNavLink(String navLink, String navTitle) {
        click(objectRepository.navTitle(navTitle));
        click(objectRepository.navLinkText(navTitle, navLink));
    }

    @When("^I click on \"([^\"]*)\" nav link$")
    public void clickNavLink(String navLink) {
        click(objectRepository.siteNavLink(navLink));
    }

    @When("^I click on \"([^\"]*)\" nav title$")
    public void clickSiteNavTitle(String navTitle) {
        click(objectRepository.navTitle(navTitle));
    }

    @When("^I validate \"([^\"]*)\" landing page with title \"([^\"]*)\"$")
    public void validateLandingPage(String landingPage, String pageTitle) throws InterruptedException {
        waitForPageLoad();
        Thread.sleep(200);
        Assert.assertTrue(getPageTitle().contains(pageTitle));
        Assert.assertTrue(getCurrentUrl().contains(landingPage));
    }

    @When("^I click on \"([^\"]*)\" hyperlink for header \"([^\"]*)\"$")
    public void clickHyperlinkForHeader(String hyperlink, String header) {
        click(objectRepository.hyperLinkForHeader(header, hyperlink));
    }

    @When("^I validate \"([^\"]*)\" landing page with title \"([^\"]*)\" on a new tab$")
    public void validateLandingPageNewTab(String landingPage, String pageTitle) throws InterruptedException {
        validateLandingPageOnNewTab(pageTitle, landingPage);
    }

    @When("^I verify \"([^\"]*)\" page url$")
    public void verifyPageUrl(String pageUrl) {
        Assert.assertTrue(getCurrentUrl().contains(pageUrl));
    }

    @When("^I click on site nav logo$")
    public void clickSiteNavHPLogo() {
        click(objectRepository.siteNavLogoV3);
    }

    @Then("^I validate \"([^\"]*)\" search on site nav$")
    public void validateSearch(String searchText) {
        click(objectRepository.searchIconRightNav);
        enterText(objectRepository.searchBox, searchText);
        click(objectRepository.searchIconSet);
    }

    @When("^I verify site nav$")
    public void verifySiteNav() {
        isDisplayed(objectRepository.siteNav);
        isDisplayed(objectRepository.siteNavLogoV3);
        isDisplayed(objectRepository.insurancePlansNav);
        isDisplayed(objectRepository.forCurrentMembersNav);
        isDisplayed(objectRepository.forBusinessNav);
        isDisplayed(objectRepository.searchIconRightNav);
    }

    @When("^I verify site nav for oracle page$")
    public void verifySiteNavForOraclePage() {
        isDisplayed(objectRepository.oracleCompanyLogo);
        isDisplayed(objectRepository.hyperLinkText("Shop our plans"));
        isDisplayed(objectRepository.hyperLinkText("For members"));
        isDisplayed(objectRepository.hyperLinkText("For business"));
        isDisplayed(objectRepository.oracleSearchIcon);
    }

    @When("^I verify site nav logo$")
    public void verifySiteNavLogo() {
        isDisplayed(objectRepository.siteNavLogo);
    }

    @When("^I verify hpuph site nav logo$")
    public void verifyHpuphSiteNavLogo() {
        isDisplayed(objectRepository.hpuphSiteNavLogo);
    }

    @When("^I verify regions site nav logo$")
    public void verifyRegionsSiteNavLogo() {
        isDisplayed(objectRepository.regionsSiteNavLogo);
    }

    @When("^I verify site nav logo for v3$")
    public void verifySiteNavLogoV3() {
        isDisplayed(objectRepository.siteNavLogoV3);
    }

    @When("^I verify what we treat site nav is displayed$")
    public void verifyWhatWeTreatSiteNavIsDisplayed() {
        isDisplayed(objectRepository.whatWeTreatNav);
    }

    @When("^I verify services site nav is displayed$")
    public void verifyServicesSiteNavIsDisplayed() {
        isDisplayed(objectRepository.servicesNav);
    }

    @When("^I verify blogs site nav is displayed$")
    public void verifyBlogsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.blogsNav);
    }

    @When("^I verify careers site nav is displayed$")
    public void verifyCareersSiteNavIsDisplayed() {
        isDisplayed(objectRepository.careersNav);
    }

    @When("^I verify contact site nav is displayed$")
    public void verifyContactsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.contactNav);
    }

    @When("^I verify what we do nav is displayed$")
    public void verifyWhatWeDoSiteNavIsDisplayed() {
        isDisplayed(objectRepository.whatWeDoNav);
    }

    @When("^I verify our services nav is displayed$")
    public void verifyOurServicesSiteNavIsDisplayed() {
        isDisplayed(objectRepository.ourServices);
    }

    @When("^I verify for doctors nav is displayed$")
    public void verifyForDoctorsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.forDoctors);
    }

    @When("^I verify more nav is displayed$")
    public void verifyMoreSiteNavIsDisplayed() {
        isDisplayed(objectRepository.more);
    }

    @When("^I verify patient and guest nav is displayed$")
    public void verifyPatientGuestSiteNavIsDisplayed() {
        isDisplayed(objectRepository.patientAndGuestNav);
    }

    @When("^I verify doctors and specialties nav is displayed$")
    public void verifyDoctorsSpecialtiesSiteNavIsDisplayed() {
        isDisplayed(objectRepository.doctorsAndSpecialtiesNav);
    }

    @When("^I verify for providers nav is displayed$")
    public void verifyForProvidersSiteNavIsDisplayed() {
        isDisplayed(objectRepository.forProvidersNav);
    }

    @When("^I verify our doctors site nav is displayed$")
    public void verifyOurDoctorsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.ourDoctorsNav);
    }

    @When("^I verify our locations site nav is displayed$")
    public void verifyOurLocationsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.ourLocationsNav);
    }

    @When("^I verify locations site nav is displayed$")
    public void verifyLocationsSiteNavIsDisplayed() {
        isDisplayed(objectRepository.locationsNav);
    }

    @When("^I verify about site nav is displayed$")
    public void verifyAboutSiteNavIsDisplayed() {
        isDisplayed(objectRepository.aboutNav);
    }

    @When("^I verify search icon is displayed$")
    public void verifySearchIconIsDisplayed() {
        isDisplayed(objectRepository.searchIconRightNav);
    }

}
