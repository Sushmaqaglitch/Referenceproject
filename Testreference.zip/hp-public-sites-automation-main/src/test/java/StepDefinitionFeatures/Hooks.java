package StepDefinitionFeatures;

import cucumber.deps.com.thoughtworks.xstream.InitializationException;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Hooks {
    public static final ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
    public final static String DEFAULT_BROWSERTYPE = "CHROME";
    //public final static String DEFAULT_BROWSERVERSION_SAUCE = "88";
    public final static String DEFAULT_BROWSERVERSION_BROWSERSTACK = "97";
    public final static String DEFAULT_BROWSERVERSION_LOCAL = "90";
    public final static String DEFAULT_BROWSERVERSION_GRID = "90";
    //public final static String DEFAULT_BROWSER_ENV = "saucelabs";
    public final static String DEFAULT_BROWSER_ENV = "browserstack";
    //public final static String DEFAULT_BROWSER_ENV = "local";
    public final static String DEFAULT_SAUCE_USER = "kartikdave";
    public final static String DEFAULT_SAUCE_ACCESS_KEY = "3d3f61e5-5999-410c-aa47-9b89b9f1849b";
    public final static String DEFAULT_BROWSERSTACK_USER = "kartikdave_mEKjsJ";
    public final static String DEFAULT_BROWSERSTACK_AUTOMATE_KEY = "LKJB4zABXfx6XGXA2xDN";
    public final static String gridURL = "https://selenium.apps.dev2-int.ocp.healthpartners.com/";
    //public final static String gridURL = "https://selenium.apps.sbx1-int.ocp.healthpartners.com/";
    public static Properties config = null;
    private static Scenario scenario;

    public static void Initialized() {
        try {
            config = new Properties();
            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "/src/test/java/Config/config.properties");
            try {
                config.load(fileInputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception ex) {
            System.out.println("Exception while initializing properties files." + ex.getMessage());
        }
//        try {
//            Local bsLocal = new Local();
//            HashMap<String, String> bsLocalArgs = new HashMap<String, String>();
//            bsLocalArgs.put("key", "LKJB4zABXfx6XGXA2xDN");
//            // Starts the Local instance with the required arguments
//            bsLocal.start(bsLocalArgs);
//            System.out.println("browserstack local is running " + bsLocal.isRunning());
//        } catch (Exception ex) {
//            System.out.println("Exception while starting browserstack local instance." + ex.getMessage());
//        }

    }

    public static WebDriver createAndGetDriver() throws MalformedURLException {
        if (driver.get() != null) {
            return driver.get();
        }

        String browserVersion = config.getProperty("browserVersion");
        String browserType = config.getProperty("browserType");
        String browserEnv = config.getProperty("browserEnv");
        String sauceUsername = config.getProperty("sauceUsername");
        String saucePassword = config.getProperty("sauceAccesskey");
        String browserStackUsername = config.getProperty("browserstackUsername");
        String browserStackPassword = config.getProperty("browserstackAutomatekey");

        if (browserEnv == null) {
            browserEnv = DEFAULT_BROWSER_ENV;
        }

        /*if (browserVersion == null && browserEnv.equals("saucelabs")) {
            browserVersion = DEFAULT_BROWSERVERSION_SAUCE;
        } else if (browserVersion == null) {
            browserVersion = DEFAULT_BROWSERVERSION_LOCAL;
        }*/

        if (browserVersion == null && browserEnv.equals("browserstack")) {
            browserVersion = DEFAULT_BROWSERVERSION_BROWSERSTACK;
        } else if (browserVersion == null) {
            browserVersion = DEFAULT_BROWSERVERSION_LOCAL;
        }

//        if (browserVersion == null && browserEnv.equals("grid")) {
//            browserVersion = DEFAULT_BROWSERVERSION_GRID;
//        } else if (browserVersion == null) {
//            browserVersion = DEFAULT_BROWSERVERSION_LOCAL;
//        }

        if (browserType == null) {
            browserType = DEFAULT_BROWSERTYPE;
        }

        //System.out.println("Browser Type is " + browserType);
        //System.out.println("Browser Env is " + browserEnv);
        //System.out.println("Browser Version is " + browserVersion);

//        if (browserEnv.equalsIgnoreCase("browserstack")) {
//            System.out.println("Browser Env is browserstack");
//            if (browserStackUsername == null || browserStackPassword == null) {
//                browserStackUsername = DEFAULT_BROWSERSTACK_USER;
//                browserStackPassword = DEFAULT_BROWSERSTACK_AUTOMATE_KEY;
//            }
//
//            DesiredCapabilities desiredCapabilities = null;
//
//            switch (browserType.toUpperCase()) {
//                case "CHROME":
//                    //desiredCapabilities = DesiredCapabilities.chrome();
//                    desiredCapabilities.setCapability("platform", "WINDOWS");
//                    desiredCapabilities.setCapability("browser_version", "latest");
//                    //desiredCapabilities.setCapability("tunnelIdentifier", "4431030b57dc0c416ea59a2afa6738b0de59dc80");
//                    break;
//
//                case "FIREFOX":
//                    //desiredCapabilities = DesiredCapabilities.firefox();
//                    desiredCapabilities.setCapability("platform", "WINDOWS");
//                    desiredCapabilities.setCapability("browser_version", "latest");
//                    desiredCapabilities.setAcceptInsecureCerts(true);
//                    break;
//
//                case "EDGE":
//                    //desiredCapabilities = DesiredCapabilities.edge();
//                    //desiredCapabilities.setCapability("platform", "WINDOWS");
//                    //desiredCapabilities.setCapability("browser_version", "latest");
//                    break;
//
//                case "SAFARI":
//                    //desiredCapabilities = DesiredCapabilities.safari();
//                    desiredCapabilities.setCapability("platform", "MAC");
//                    desiredCapabilities.setCapability("browser_version", "latest");
//                    break;
//
//                case "IPHONE":
//                    //desiredCapabilities = DesiredCapabilities.iphone();
//                    //desiredCapabilities.setCapability("appiumVersion", "1.17.1");
//                    //desiredCapabilities.setCapability("platformVersion","13.2");
//                    desiredCapabilities.setCapability("device", "iPhone 12 Pro");
//                    desiredCapabilities.setCapability("real_mobile", "true");
//                    desiredCapabilities.setCapability("os_version", "14");
//                    desiredCapabilities.setCapability("browserName", "safari");
//                    //desiredCapabilities.setCapability("platformName","iOS");
//                    break;
//                default:
//                    throw new IllegalArgumentException("Unsupported platform/Browser configuration " + browserType);
//            }
//
//            URL browserStackUrl = new URL("http://" + browserStackUsername + ":" + browserStackPassword + "@hub-cloud.browserstack.com/wd/hub");
//            System.out.println("Browserstack url is " + browserStackUrl);
//
//            //desiredCapabilities.setCapability("browserstack.local", "true");
//            desiredCapabilities.setCapability("version", browserVersion);
//            desiredCapabilities.setCapability("maxDuration", 2700);
//            desiredCapabilities.setCapability("name", "care overview page");
//            //desiredCapabilities.setCapability("avoidProxy", true);
//            //desiredCapabilities.setCapability("autoAcceptAlerts", true);
//            //desiredCapabilities.setCapability("recordVideo", true);
//            //desiredCapabilities.setCapability("idleTimeout", 120);
//            //desiredCapabilities.setCapability("commandTimeout", 240);
//
//            setDriver(new RemoteWebDriver(browserStackUrl, desiredCapabilities));
//        }
        if (browserEnv.equalsIgnoreCase("local")) {
            //System.out.println("launching local browser");

            switch (browserType.toUpperCase()) {
                case "CHROME":
                    //System.out.println("Browser type on local is " + browserType);
                    System.setProperty("webdriver.chrome.driver", "C:\\Users\\f8209\\chromedriver\\chromedriver.exe");
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("--remote-allow-origins=*", "--incognito", "--start-maximized");
                    setDriver(new ChromeDriver(options));
                    break;
                case "FIREFOX":
                    //System.out.println("Browser type on local is " + browserType);
                    System.setProperty("webdriver.gecko.driver", "C:\\Users\\f8209\\geckodriver\\geckodriver.exe");
                    setDriver(new FirefoxDriver());
                    break;
                case "EDGE":
                    //System.out.println("Browser type on local is " + browserType);
                    System.setProperty("webdriver.edge.driver", "C:\\Users\\f8209\\edgedriver\\msedgedriver.exe");
                    setDriver(new EdgeDriver());
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported local platform/browser configuration " + browserType);
            }
        } else {
            //System.out.println("Browser environment is selenium grid browser");
            if ("CHROME".equalsIgnoreCase(browserType)) {
                //System.out.println("Browser type on selenium grid is " + browserType);
                //System.setProperty("webdriver.chrome.driver", "src/main/resources/chromeDriver/chromedriver.exe");
                String featureName = scenario.getName().split(";")[0];
                ChromeOptions options = new ChromeOptions();
                Map<String, Object> additionalOptions = new HashMap<>();
                additionalOptions.put("team_name", "Public Sites");
                additionalOptions.put("testName", featureName);
                additionalOptions.put("idleTimeout", 45);
//                options.setCapability("pageLoad", 600000);
//                options.setCapability("script", 60000);
                options.setCapability("additional:options", additionalOptions);
                options.addArguments(
                        "--incognito",
                        "--no-sandbox",
                        "--remote-allow-origins=*",
                        "--start-maximized",
                        //"--headless",
                        "window-size=1920,1080",
                        "--disable-gpu",
                        "--disable-dev-shm-usage",
                        "--disable-popup-blocking",
                        "--ignore-certificate-errors",
                        "--browserTimeout=120",
                        "--cleanUpCycle=5000",
                        "--timeout=90",
                        "--sessionTimeout=90"
                );
                options.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation", "disable-infobars"));
                options.setAcceptInsecureCerts(true);
                setDriver(new RemoteWebDriver(new URL(gridURL), options));
            } else {
//                System.out.println("Browser environment is selenium grid browser");
//                if ("CHROME".equalsIgnoreCase(browserType)) {
//                    System.out.println("Browser type on selenium grid is " + browserType);
//                    //System.setProperty("webdriver.chrome.driver", "src/main/resources/chromeDriver/chromedriver.exe");
//
//                    ChromeOptions options = new ChromeOptions();
//                    options.setCapability("idleTimeout", 45);
//                    options.addArguments("--start-maximized",
//                            "--headless",
//                            "window-size=1920,1080",
//                            "--disable-popup-blocking",
//                            "--ignore-certificate-errors");
//                    options.setAcceptInsecureCerts(true);
//                    setDriver(new RemoteWebDriver(new URL(gridURL), options));
//                    //setDriver(new RemoteWebDriver(new URL("http://selenium-grid.boghi-dev.healthpartners.com/wd/hub"), desiredCapabilities));
            }
            if ("FIREFOX".equalsIgnoreCase(browserType)) {
                //System.out.println("Browser type on selenium grid is " + browserType);
                FirefoxOptions options = new FirefoxOptions();
                options.setCapability("idleTimeout", 45);
                options.addArguments("--start-maximized",
                        "--headless",
                        "window-size=1920,1080",
                        "--disable-popup-blocking",
                        "--ignore-certificate-errors");
                options.setAcceptInsecureCerts(true);
                setDriver(new RemoteWebDriver(new URL(gridURL), options));
            } else if ("EDGE".equalsIgnoreCase(browserType)) {
                //System.out.println("Browser type on selenium grid is " + browserType);
                EdgeOptions options = new EdgeOptions();
                options.setCapability("idleTimeout", 45);
                options.addArguments("--start-maximized",
                        "--headless",
                        "window-size=1920,1080",
                        "--disable-popup-blocking",
                        "--ignore-certificate-errors");
                options.setAcceptInsecureCerts(true);
                setDriver(new RemoteWebDriver(new URL(gridURL), options));
            }
        }
        driver.get().manage().deleteAllCookies();
        driver.get().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.get().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        return getDriver();
    }

    public static WebDriver getDriver() throws InitializationException {
        if (driver.get() != null) {
            return driver.get();
        }

        throw new InitializationException("Browser driver not initialized");
    }

    private static void setDriver(WebDriver inputDriver) {
        driver.set(inputDriver);
    }

    @Before
    public void SetUp(Scenario scenario) throws MalformedURLException {
        Hooks.scenario = scenario;
        Initialized();
        createAndGetDriver();
    }

    @After
    public void TearDown(Scenario scenario) {
        WebDriver currentDriver = getDriver();
        if (scenario.isFailed()) {
            try {
                scenario.log("Current Page URL is " + driver.get().getCurrentUrl());
                /*JavascriptExecutor jse = (JavascriptExecutor)driver;
// To mark the test as passed
                jse.executeScript("browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": {\"status\": \"passed\", \"reason\": \"<reason>\"}}");
// To mark the test as failed
                jse.executeScript("browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": {\"status\": \"failed\", \"reason\": \"<reason>\"}}");
                byte[] screenshot = ((TakesScreenshot) driver.get()).getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png");*/
            } catch (WebDriverException somePlatformDoNotSupportScreenshots) {
                System.err.println(somePlatformDoNotSupportScreenshots.getMessage());
            }
        }
        if (currentDriver != null) {
            setDriver(null);
            currentDriver.quit();
        }
    }
}
