/*
package StepDefinitionFeatures;

import org.openqa.selenium.WebDriver;

public class LocalDriverFactory {
    public static WebDriver createInstance(String browserName){
        WebDriver driver;
        browserName = (browserName != null) ? browserName : "firefox";
        return driver;
    }
}
*/
