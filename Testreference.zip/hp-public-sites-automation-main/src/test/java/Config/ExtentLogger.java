package Config;

import com.codeborne.selenide.WebDriverRunner;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentLogger {

    public static ExtentReports globalExtent = ExtentManager.getInstance();
    public static ExtentTest globalExtentTest;
    private final String packageName = this.getClass().getPackage().getName();
    SoftAssert softAssert = new SoftAssert();

    public static String getTestResult(ITestResult result) {
        String testMethodName = result.getMethod().getMethodName();
        String testResult;
        switch (result.getStatus()) {
            case ITestResult.SUCCESS:
                testResult = "PASS";
                break;

            case ITestResult.FAILURE:
                testResult = "FAIL";
                break;

            case ITestResult.SKIP:
                testResult = "SKIPPED";
                break;

            case ITestResult.STARTED:
                testResult = "STARTED";
                break;

            default:
                testResult = "INVALID STATUS";
        }
        return testResult;
    }

    public static String getScreenShotName(String screeShotName) {
        String testRunDate = new SimpleDateFormat("yyMMddhhmmss").format(new Date());
        String screenShot = screeShotName + testRunDate.replace(":", "_").replace(" ", "") + ".png";
        return screenShot;
    }

    public void endTest(ITestResult result) {
        String testMethodName = result.getMethod().getMethodName();
        String testResult = getTestResult(result);
        String path = takeScreenShot(testMethodName, result);
        logInfo("Test Status: " + testResult);
        if (testResult.equals("FAIL")) {
            logInfo("=== Test method " + testMethodName + " failed Here ===");
            logStatus(LogStatus.FAIL, globalExtentTest.addScreenCapture(path));
        }
        logStatus(LogStatus.INFO, "------------------- END -------------------");
        globalExtent.endTest(globalExtentTest);
        globalExtent.flush();
    }

    public void startDefaultTest() {
        globalExtentTest = globalExtent.startTest("Public Website automation tests", "Automation src/test/resources for Public Websites");
    }

    public void startTest(String testName, String testDesc, String category, String sprintName) {
        if (sprintName == null) {
            sprintName = category;
        }
        globalExtentTest = globalExtent.startTest(testName, testDesc).assignCategory(sprintName, category);
    }

    public String takeScreenShot(String methodName, ITestResult result) {

        String fileName = null;
        if (result.getStatus() == 2) {

            fileName = getScreenShotName(methodName);
            String dir = System.getProperty("user.dir") + "/ExtentReports/";
            new File(dir).mkdirs();
            String path = dir + fileName;

            try {
                File screenShot = ((TakesScreenshot) WebDriverRunner.getWebDriver()).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(screenShot, new File(path));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return fileName;
    }

    public void logInfo(String message) {
        globalExtentTest.log(LogStatus.INFO, message);
    }

    public void logStatus(LogStatus status, String message) {
        globalExtentTest.log(status, message);
    }

    public void logException(LogStatus status, String message) {
        logStatus(status, message);
    }

    public void assertEquals(Object actual, Object expected) {
        try {
            Assert.assertEquals(expected, actual);
        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "Expected:[" + expected + "] but found: [" + actual + "] " + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void assertEquals(Object actual, Object expected, String fieldName) {
        try {
            Assert.assertEquals(expected, actual);
            logStatus(LogStatus.PASS, fieldName + "--" + actual.toString());
        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "Expected:[" + expected + "] but found: [" + actual + "] " + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void assertNotEquals(Object actual, Object expected) {
        try {
            Assert.assertNotSame(actual, expected);
        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "Expected:[" + expected + "] but found: [" + actual + "] " + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void assertNotNull(Object object) {
        try {
            Assert.assertNotNull(object);

        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "NULL Condition Failed!!!" + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void assertTrue(boolean condition) {
        assertTrue(condition, "");
    }

    public void assertTrue(boolean condition, String message) {
        try {
            Assert.assertTrue(condition);
            if (message != "")
                logStatus(LogStatus.PASS, message);

        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "Condition Failed!!! [" + message + "] " + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void assertFalse(boolean condition) {
        assertFalse(condition, "");
    }


    public void assertFalse(boolean condition, String message) {
        try {
            Assert.assertFalse(condition);

        } catch (AssertionError e) {
            logStatus(LogStatus.FAIL, "Condition Failed!!! [" + message + "] " + ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public void softAssertEquals(Object actual, Object expected) {
        softAssert.assertEquals(actual, expected);
    }

    public void softAssertAll() {
        try {
            softAssert.assertAll();
        } catch (Throwable e) {
            logStatus(LogStatus.FAIL, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }
}
