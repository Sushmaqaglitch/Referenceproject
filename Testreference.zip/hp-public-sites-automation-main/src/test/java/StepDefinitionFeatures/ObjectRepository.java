package StepDefinitionFeatures;

import org.openqa.selenium.By;

public class ObjectRepository {

    // Site Nav Elements
    final By siteNavLogo = By.id("siteNavLogo");
    final By hpuphSiteNavLogo = By.xpath("//*[@class='nav-image-container']//*[contains(@alt,'HealthPartners UnityPoint Health logo')]");
    final By siteNav = By.className("hp-site-navigation");
    final By shopOurPlansNav = By.id("nav-shopour-plans");
    final By insurancePlansNav = By.id("nav-insuranceplans");
    final By forMembersNav = By.id("nav-formembers");
    final By forCurrentMembersNav = By.id("nav-forcurrent-members");
    final By forBusinessNav = By.id("nav-forbusinesses");
    final By searchIconRightNav = By.xpath(".//*[contains(@class,'right-nav')]//*[contains(@class,'search-icon')]");
    final By oracleCompanyLogo = By.xpath(".//*[contains(@class,'company-logo')]");
    final By oracleSearchIcon = By.xpath(".//*[contains(@class,'search-icon')]");
    final By whatWeTreatNav = By.id("nav-whatwe-treat");
    final By servicesNav = By.id("nav-services");
    final By blogsNav = By.id("nav-blog");
    final By careersNav = By.id("nav-careers");
    final By contactNav = By.id("nav-contact");
    final By ourDoctorsNav = By.id("nav-ourdoctors");
    final By ourLocationsNav = By.id("nav-ourlocations");
    final By locationsNav = By.id("nav-locations");
    final By aboutNav = By.id("nav-about");
    final By regionsSiteNavLogo = By.xpath(".//*[@class='sc-feJyhm lbSZTB']");
    final By siteNavLogoV3 = By.xpath(".//*[contains(@class,'nav-image-container')]");
    final By whatWeDoNav = By.id("nav-whatwe-do");
    final By ourServices = By.id("nav-ourservices");
    final By forDoctors = By.id("nav-fordoctors");
    final By more = By.id("nav-more");
    final By patientAndGuestNav = By.id("nav-patient&-guest");
    final By doctorsAndSpecialtiesNav = By.id("nav-doctors&-specialties");
    final By forProvidersNav = By.id("nav-forproviders");
    final By searchIconSet = By.xpath(".//*[@class='search-icon-set']//*[@class='search-icon']");
    final By searchBox = By.id("search-box");
    //footer elements
    final By embedPdf = By.xpath("//embed[@type='application/pdf']");
    final By topFooter = By.className("hp-page-footer-top");
    final By oracleTopFooter = By.xpath(".//*[contains(@class,'links-row')]");
    final By middleFooter = By.className("hp-page-footer-middle");
    final By oracleMiddleFooter = By.xpath(".//*[contains(@class,'languages-row')]");
    final By bottomFooter = By.className("hp-page-footer-bottom");
    final By oracleBottomFooter = By.xpath(".//*[contains(@class,'notices-row')]");
    final By chatBubble = By.xpath(".//*[@id='intouch-medicare-chat-footer']/hp5-chat-bubble");
    //global nav elements
    final By globalNavHealthPartnersDropDown = By.xpath(".//hp5-site-navigation//*[@class='global-nav-dropdown-heading-wrapper']");
    final By oracleGlobalNavHPDropDown = By.className("global-nav-dropdown-header");
    final By v3GlobalNavHPDroDown = By.className("globalnav-dropdown-dropdown");
    final By globalNav = By.xpath(".//hp5-site-navigation//*[@class='global-nav']");
    final By v3GlobalNav = By.className("globalnav-global-wrapper");
    final By globalNavBar = By.id("navbar");
    final By globalNavItem = By.xpath(".//*[@class='sc-kAzzGY cmOrRM']");
    final By c2BackgroundImageText = By.className("c2-image-container");
    final By notification = By.xpath(".//hp5-notification/div[@class='notification type-info show']");
    final By doctorGeoSearch = By.xpath("//hp5-input-search[@element-id='doctor-geosearch']");
    final By alert = By.xpath(".//hp5-alert/section/div[@class='alert-wrapper hp-alert--info']");
    final By c0BackgroundImage = By.xpath(".//*[contains(@class,'c0-image-container-background')]");
    final By primaryWell = By.xpath(".//hp5-well-primary//*[contains(@class,'well-primary')]");
    final By doctorsLoadingPage = By.xpath("//hpfc-doctors-loading-page/div/hp5-container");

    By navTitle(String navTitle) {
        return By.xpath("//*[contains(@class,'nav-option')]//*[contains(text(),'" + navTitle + "')]");
    }

    By hyperLinkForHeader(String headerName, String hyperlink) {
        return By.xpath(".//*[@data-row-header='Plan name']//*[contains(text(),'" + headerName + "')]//..//..//..//a[contains(text(),'" + hyperlink + "')]");
    }

    By siteNavLink(String siteNavLink) {
        return By.xpath("//*[@class='nav-link'][contains(text(),'" + siteNavLink + "')]");
    }

    By navLinkCategory(String category, String navLink) {
        return By.xpath("//span[@class='categorized-title'][contains(text(),'" + category + "')]/..//*[@class='nav-link'][contains(text(),'" + navLink + "')]");
    }

    final By spanHyperLinkText(String linkText) {
        return By.xpath(".//span[contains(text(),'" + linkText + "')]");
    }

    final By subNav(String title) {
        return By.xpath("//nav[@class='nav']//*[contains(text(),'" + title + "')]");
    }

    final By hyperLinkText(String linkText) {
        return By.xpath(".//a[text()= '" + linkText + "']");
    }

    By navLinkText(String navLink, String subMenuLinkText) {
        return By.xpath("//*[contains(@class,'nav-option')]//*[contains(text(),'" + navLink + "')]//..//..//..//a[contains(text(),'" + subMenuLinkText + "')]");
    }

    By navSpanLinkText(String navLink, String subMenuLinkText) {
        return By.xpath("//*[contains(@class,'nav-option')]//*[contains(text(),'" + navLink + "')]//..//..//..//span[contains(text(),'" + subMenuLinkText + "')]");
    }

    final By externalLink(String linkText) {
        return By.xpath(".//*[contains(text(),'" + linkText + "')]//*[@class='external-icon']");
    }

    final By ariaLabelText(String ariaLabelText) {
        return By.xpath(".//input[contains(@aria-label, \"" + ariaLabelText + "\")]");
    }

    final By textAreaAriaLabel(String ariaLabelText) {
        return By.xpath(".//textarea[contains(@aria-label, \"" + ariaLabelText + "\")]");
    }

    final By selectAriaLabelText(String ariaLabelText) {
        return By.xpath(".//select[contains(@aria-label, \"" + ariaLabelText + "\")]");
    }

    final By buttonAriaLabelText(String ariaLabelText) {
        return By.xpath(".//button[contains(@aria-label, \"" + ariaLabelText + "\")]");
    }

    final By ariaLabelTextForHeader(String ariaLabelText, String header) {
        return By.xpath(".//div/*[contains(text(),\"" + header + "\")]//..//..//..//..//*[contains(@aria-label,\"" + ariaLabelText + "\")]");
    }

    final By checkboxLabel(String label) {
        return By.xpath(".//*[@type='checkbox'][contains(@aria-label, \"" + label + "\")]");
    }

    final By bodyContent(String text) {
        return By.xpath(".//*[contains(text(), \"" + text + "\")]");
    }

    final By datePicker() {
        return By.xpath(".//*[contains(@class,'guideDatePicker')]");
    }

    final By labelText(String label) {
        return By.xpath(".//label[contains(text(),'" + label + "')]");
    }

    final By hyperLinkTextInSection(String linkText, String section) {
        return By.xpath(".//*[contains(text(),'" + section + "')]//a[contains(text(),'" + linkText + "')]");
    }

    final By hyperLinkTextInAccordion(String linkText, String accordion) {
        return By.xpath(".//hp5-faq-accordion[@question='" + accordion + "']//*[contains(text(),'" + linkText + "')]");
    }

    final By hyperLinkTextBasic(String linkText) {
        return By.xpath("//hp5-link-text-basic/a[contains(text(),'" + linkText + "')]");
    }

    final By segmentedControlTabName(String name) {
        return By.xpath("//hp5-segmented-control-tab[@name='" + name + "']");
    }

    //Breadcrumb elements
    By breadcrumbText(String text) {
        return By.xpath(".//nav[@aria-label='breadcrumb']//*[contains(text(),'" + text + "')]");
    }

    By breadcrumbLink(String linkText) {
        return By.xpath(".//nav[@aria-label='breadcrumb']//a[contains(text(),'" + linkText + "')]");
    }

    By topFooterListItem(String columnHeading, String footerItemName) {
        return By.xpath("//*[@class='footer-column-heading'][contains(text(),'" + columnHeading + "')]//..//*[@class='footer-top-list']//..//*[contains(text(),'" + footerItemName + "')]");
    }

    By middleFooterListItem(String footerItemName) {
        return By.xpath("//div[@class='rows-sm-up']//a[contains(text(),'" + footerItemName + "')]");
    }

    By bottomFooterListItem(String footerItemName) {
        return By.xpath("//*[@class='footer-bottom-list']//..//*[contains(text(),'" + footerItemName + "')]");
    }

    By globalNavListItemBtn(String btnText) {
        return By.xpath(".//hp5-site-navigation//*[contains(@class,'global-nav-button')]//*[contains(text(),'" + btnText + "')]");
    }

    By globalNavListItemLink(String linkText) {
        return By.xpath(".//hp5-site-navigation//*[contains(@class,'global-nav-link')]//*[contains(text(),'" + linkText + "')]");
    }

    By v3globalNavListItemBtn(String btnText) {
        return By.xpath(".//*[contains(@class,'globalnav-list-wrapper')]//*[contains(text(),'" + btnText + "')]");
    }

    By btnTextElement(String btnText) {
        return By.xpath("//button[contains(text(),'" + btnText + "')]");
    }

    By transparentBannerHeadingText(String text) {
        return By.xpath("//div[contains(@class,'transparent-box-in-banner-full')]/h1[contains(text(),'" + text + "')]");
    }

    By textElement(String text) {
        return By.xpath(".//li[contains(text(),'" + text + "')]");
    }

    By anchorLinkText(String text) {
        return By.xpath("//hp5-site-navigation//a[contains(text(),'" + text + "')]");
    }

    //common elements
    By bannerHeadingText(String text) {
        return By.xpath("//div[contains(@class,'background-image')]//../..//..//*[contains(text(),'" + text + "')]");
    }

    By mediaCaption(String videoText) {
        return By.xpath("//hp5-media-caption[@video-title-text='" + videoText + "']");
    }

    By quoteContent(String quote) {
        return By.xpath(".//*[@class='quote-content']//*[contains(text(),'" + quote + "')]");
    }

    By ctaButtonText(String buttonText) {
        return By.xpath(".//span[contains(text(),'" + buttonText + "')]");
    }

    By buttonText(String buttonText) {
        return By.xpath(".//button[contains(text(),'" + buttonText + "')]");
    }

    By paragraph(String paragraphText) {
        return By.xpath(".//p[contains(text(),\"" + paragraphText + "\")]");
    }

    By fieldErrorMessage(String msgText, String fieldName) {
        return By.xpath(".//*[contains(text(),\"" + msgText + "\")]//..//*[contains(@aria-label,\"" + fieldName + "\")]");
    }

    By navOption(String nav) {
        return By.xpath(".//*[contains(@class,'nav-option')]//*[contains(text(),'" + nav + "')]");
    }

    By divHyperLinkText(String linkText) {
        return By.xpath(".//div[contains(text(),'" + linkText + "')]");
    }

    By inputBox(String text) {
        return By.xpath("//input[contains(@aria-label, '" + text + "')]");
    }

    By headerText(String text) {
        return By.xpath(".//h1[contains(@class,'hp-heading')][contains(text(),'" + text + "')]");
    }

    By iconName(String iconName) {
        return By.xpath(".//*[@icon-name='" + iconName + "']");
    }

    By footerhref(String text, String hrefLink) {
        return By.xpath(".//div[@class='rows-sm-up']//*[contains(text(),'" + text + "')][contains(@href,'" + hrefLink + "')]");
    }

    By href(String text, String hrefLink) {
        return By.xpath(".//*[contains(text(),'" + text + "')][contains(@href,'" + hrefLink + "')]");
    }

    By hrefLink(String href) {
        return By.xpath(".//*[contains(@href,'" + href + "')]");
    }

    By spanLinkhref(String hrefLink, String text) {
        return By.xpath(".//*[contains(@href,'" + hrefLink + "')]//*[contains(text(),'" + text + "')]");
    }

    By socialMediaList(String socialMedia) {
        return By.xpath("//*[@class='social-media-list']//*[contains(@name,'" + socialMedia + "')]");
    }

    By regularHoursDay(String hours, String day) {
        return By.xpath(".//*[@class='regular-hours']//span[@class='day'][contains(text(),'" + day + "')]//..//span[@class='hours'][contains(text(),'" + hours + "')]");
    }

    By callToActionPrimary(String ctaButton) {
        return By.xpath(".//*[contains(@class,'hp-call-to-action')][contains(@class,'primary')]//*[contains(text(),'" + ctaButton + "')]");
    }

    By c3TextContainerNoImage(String bannerText) {
        return By.xpath(".//hp5-content-page-banner[@heading-text='" + bannerText + "']");
    }

    By c0HeadingText(String headerText) {
        return By.xpath(".//*[@class='c0-heading'][contains(text(),'" + headerText + "')]");
    }

    By c2BackgroundImageHeadingText(String headingText) {
        return By.xpath(".//*[contains(@class,'c2-image-container')]//..//..//*[contains(text(),'" + headingText + "')]");
    }

    By featureStoryHeadingText(String headingText) {
        return By.xpath(".//hp5-feature-story[@heading-text='" + headingText + "']");
    }

    By imageSrcPath(String path) {
        return By.xpath(".//*[contains(@image-src,'" + path + "')]");
    }

    By srcPath(String path) {
        return By.xpath(".//*[contains(@src,'" + path + "')]");
    }

    By videoSrcPath(String path) {
        return By.xpath(".//*[@video-src='" + path + "']");
    }

    By callToActionBarText(String ctaText) {
        return By.xpath(".//hp5-call-to-action-bar[@text='" + ctaText + "']");
    }

    By subNavTitle(String title) {
        return By.xpath(".//*[@id='hpSubNavTitle'][contains(text(),'" + title + "')]");
    }

    By subNavItem(String item) {
        return By.xpath("//ul[@class='nav-items']//li//*[contains(text(),'" + item + "')]");
    }

    By mediaContentBlockText(String headingText) {
        return By.xpath(".//hp5-media-content-block[@heading-text='" + headingText + "']");
    }

    By variableContentBlockHorizontalText(String headingText) {
        return By.xpath(".//hp5-variable-content-block-horizontal[@heading-text='" + headingText + "']");
    }

    By variableContentBlockVerticalText(String headingText) {
        return By.xpath(".//hp5-variable-content-block-vertical[@heading-text='" + headingText + "']");
    }

    By ctaCard(String headingText) {
        return By.xpath("//hp5-call-to-action-card[@heading-text='" + headingText + "']");
    }

    By ctaText(String ctaText) {
        return By.xpath("//hp5-call-to-action-card[@cta-text='" + ctaText + "']");
    }

    By callToActionBarPrimaryBtnText(String btnText) {
        return By.xpath(".//hp5-call-to-action-bar//.//*[contains(@class,'primary')]//*[contains(text(),'" + btnText + "')]");
    }

    By callToActionBarSecondaryBtnText(String btnText) {
        return By.xpath(".//hp5-call-to-action-bar//.//*[contains(@class,'secondary')]//*[contains(text(),'" + btnText + "')]");
    }

    By tooltipContentText(String text) {
        return By.xpath(".//*[contains(@class,'tooltip-content')]//*[contains(text(),'" + text + "')]");
    }

    By icon(String name) {
        return By.xpath("//hp5-icon[contains(@name,'" + name + "')]");
    }

    By v3socialMediaIcon(String iconName) {
        return By.xpath("//*[contains(@class,'" + iconName + "')]");
    }

    By headingSectionMiniSites(String heading) {
        return By.xpath(".//section[contains(@class,'heading-section minisites-heading-section')][contains(text(),'" + heading + "')]");
    }

    By headingSection(String heading) {
        return By.xpath(".//section[contains(@class,'heading-section')]/*[contains(text(),'" + heading + "')]");
    }

    By linkText(String linkText) {
        return By.xpath(".//a[contains(text(),'" + linkText + "')][contains(@class,'hp-link-text')]");
    }

    By buttonName(String name) {
        return By.xpath("//button[@name='" + name + "']");
    }

    By popOver(String headingText) {
        return By.xpath(".//*[@heading-text='" + headingText + "']//*[@class='badge-container']");
    }

    By popOverForSection(String section) {
        return By.xpath(".//*[contains(section,'" + section + "')]//*[@class='badge-container']");
    }

    By personNameCard(String personName) {
        return By.xpath("//hp5-person-card[@person-name='" + personName + "']");
    }

    By textContent(String text) {
        return By.xpath("//span[@class='text-content'][text()='" + text + "']");
    }

    By imageCard(String headingText) {
        return By.xpath(".//hp5-image-card-vertical[@heading-text='" + headingText + "']");
    }

    By imageCardHorizontal(String headingText) {
        return By.xpath(".//hp5-image-card-horizontal[@heading-text='" + headingText + "']");
    }

    By tertiaryLinkText(String linkText) {
        return By.xpath(".//hp5-link-text-tertiary[@text='" + linkText + "']");
    }

    By tertiarySpanLinkText(String linkText) {
        return By.xpath(".//hp5-link-text-tertiary//span[contains(text(),'" + linkText + "')]");
    }

    By callToActionCardButtonText(String ctaCardButtonText) {
        return By.xpath(".//hp5-call-to-action-card/.//hp5-call-to-action//*[contains(text(),'" + ctaCardButtonText + "')]");
    }

    By expandCollapse(String expandCollapseText) {
        return By.xpath(".//hp5-expand-collapse//span[contains(text(),'" + expandCollapseText + "')]");
    }

    By articleCard(String headingText) {
        return By.xpath(".//hp5-article-card[@heading-text='" + headingText + "']");
    }

    By hpArticleCard(String headingText) {
        return By.xpath(".//*[@class='hp-article-card']//*[text()='" + headingText + "']");
    }

    By faqAccordion(String questionText) {
        return By.xpath(".//hp5-faq-accordion//*[contains(text(),'" + questionText + "')]");
    }

    By variableContentBlockVerticalBtnText(String btnText, String headingText) {
        return By.xpath(".//hp5-variable-content-block-vertical[@heading-text='" + headingText + "']//*[contains(text(),'" + btnText + "')]");
    }

    By mediaContentBlockBtnText(String btnText, String contentText) {
        return By.xpath(".//*[@class='media-content-block']//p[contains(text(),'" + contentText + "')]/..//..//..//span[contains(text(),'" + btnText + "')]");
    }

    By imageSrc(String src) {
        return By.xpath(".//img[contains(@src,'" + src + "')]");
    }

    By iconCardHorizontal(String headingText) {
        return By.xpath(".//hp5-icon-card-horizontal[@heading-text='" + headingText + "']");
    }

}
