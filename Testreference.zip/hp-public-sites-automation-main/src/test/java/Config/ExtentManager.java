package Config;

import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {

    private static ExtentReports extent;

    public static ExtentReports getInstance() {
        if (extent == null) {
            extent = new ExtentReports("ExtentReports/PublicWebsitesTestReport.html", true);

            // optional
            extent.config()
                    .documentTitle("Public Websites Automation Report")
                    .reportName("AUTOMATED TESTS - ")
                    .reportHeadline("PWT TEAM");

            // optional
            extent
                    .addSystemInfo("Environment", "PROD");
        }
        return extent;
    }
}
