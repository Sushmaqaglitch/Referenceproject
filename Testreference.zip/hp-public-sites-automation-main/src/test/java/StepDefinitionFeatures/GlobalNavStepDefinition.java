package StepDefinitionFeatures;


import io.cucumber.java.en.And;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class GlobalNavStepDefinition extends PageObjectBase {
    public final ThreadLocal<WebDriver> driver = Hooks.driver;
    final ObjectRepository objectRepository = new ObjectRepository();

    @And("^I validate \"([^\"]*)\" global nav with \"([^\"]*)\" landing page$")
    public void validateGlobalNav(String text, String landingPageText) throws InterruptedException {
        click(objectRepository.globalNavHealthPartnersDropDown);
        if (text.equalsIgnoreCase("Healthy Living") || text.equalsIgnoreCase("Living Well")) {
            click(objectRepository.anchorLinkText(text));
            switch (text.trim()) {
                case "Healthy Living":
                case "Living Well":
                    Assert.assertEquals(getPageTitle(), "Living Well | HealthPartners");
                    break;
            }
            isDisplayed(objectRepository.transparentBannerHeadingText(landingPageText));
        } else if (text.equalsIgnoreCase("Clinics & hospitals")) {
            click(objectRepository.anchorLinkText(text));
            Assert.assertTrue(getCurrentUrl().contains("care"));
        } else if (text.equalsIgnoreCase("Contact")) {
            click(objectRepository.anchorLinkText(text));
            Assert.assertEquals(getPageTitle(), "Contact us | HealthPartners");
            Assert.assertTrue(getCurrentUrl().contains("contact"));
            isDisplayed(objectRepository.breadcrumbText("Contact us"));
        } else if (text.equalsIgnoreCase("Sign in")) {
            click(objectRepository.globalNavListItemBtn(text));
            Thread.sleep(500);
            Assert.assertEquals(getPageTitle(), "Sign in or create an account | HealthPartners");
            Assert.assertTrue(getCurrentUrl().contains("login"));
            isDisplayed(objectRepository.btnTextElement(text));
        } else if (text.equalsIgnoreCase("Pay bill")) {
            click(objectRepository.globalNavListItemLink(text));
            Assert.assertEquals(getPageTitle(), "Pay a HealthPartners, Park Nicollet or TRIA bill | HealthPartners");
            Assert.assertTrue(getCurrentUrl().contains("pay-bill"));
            isDisplayed(objectRepository.textElement(landingPageText));
        } else {
            click(objectRepository.anchorLinkText(text));
            switch (text.trim()) {
                case "Pharmacy":
                    Assert.assertEquals(getPageTitle(), "Pharmacy | Drug lists, resources and refills | HealthPartners");
                    break;
                case "Health care":
                    Assert.assertEquals(getPageTitle(), "HealthPartners & Park Nicollet – Clinics & Hospitals in MN and western WI");
                    isDisplayed(objectRepository.c0BackgroundImage);
                    isDisplayed(objectRepository.c0HeadingText(landingPageText));
                    break;
                case "HealthPartners home":
                    Assert.assertEquals(getPageTitle(), "HealthPartners – Top-Rated insurance and health care in Minnesota and Wisconsin");
                    isDisplayed(objectRepository.c0BackgroundImage);
                    isDisplayed(objectRepository.c0HeadingText(landingPageText));
                    break;
                case "Health insurance":
                    Assert.assertEquals(getPageTitle(), "Health insurance plans for the way you live | HealthPartners");
                    isDisplayed(objectRepository.c0BackgroundImage);
                    isDisplayed(objectRepository.c0HeadingText(landingPageText));
                    break;
                case "About":
                    Assert.assertEquals(getPageTitle(), "About | HealthPartners");
                    isDisplayed(objectRepository.c2BackgroundImageHeadingText(landingPageText));
                    break;
                case "Careers":
                    Assert.assertEquals(getPageTitle(), "Careers at HealthPartners | Job Opportunities");
                    isDisplayed(objectRepository.c2BackgroundImageHeadingText(landingPageText));
                    break;
            }
        }
        driver.get().navigate().back();
        click(objectRepository.globalNavHealthPartnersDropDown);
    }

    @And("^I click on \"([^\"]*)\"$")
    public void clickOnLinkText(String text) {
        click(objectRepository.anchorLinkText(text));
    }

    @And("^I validate \"([^\"]*)\" landing page$")
    public void validateLandingPage(String landingPageText) {
        isDisplayed(objectRepository.bannerHeadingText(landingPageText));
        driver.get().navigate().back();
    }

    @And("^I verify global nav$")
    public void verifyGlobalNav() {
        isDisplayed(objectRepository.globalNav);
        isDisplayed(objectRepository.globalNavHealthPartnersDropDown);
        isDisplayed(objectRepository.globalNavListItemBtn("Sign in"));
    }

    @And("^I verify global nav bar$")
    public void verifyGlobalNavBar() {
        isDisplayed(objectRepository.globalNavBar);
        isDisplayed(objectRepository.globalNavItem);
    }

    @And("^I verify global nav for oracle page$")
    public void verifyOracleGlobalNav() {
        isDisplayed(objectRepository.oracleGlobalNavHPDropDown);
        isDisplayed(objectRepository.hyperLinkText("Log in"));
    }

    @And("^I verify v3 global nav$")
    public void verifyV3GlobalNav() {
        isDisplayed(objectRepository.v3GlobalNav);
        isDisplayed(objectRepository.v3GlobalNavHPDroDown);
    }

    @And("^I verify pay bill global nav$")
    public void verifyPayBillGlobalNav() {
        isDisplayed(objectRepository.globalNavListItemLink("Pay bill"));
    }

    @And("^I verify v3 pay bill global nav$")
    public void verifyv3PayBillGlobalNav() {
        isDisplayed(objectRepository.v3globalNavListItemBtn("Pay Bill"));
    }

    @And("^I verify sign in global nav$")
    public void verifySignInGlobalNav() {
        isDisplayed(objectRepository.globalNavListItemBtn("Sign in"));
    }

    @And("^I verify v3 sign in global nav$")
    public void verifyv3SignInGlobalNav() {
        isDisplayed(objectRepository.v3globalNavListItemBtn("Sign in"));
    }
}
