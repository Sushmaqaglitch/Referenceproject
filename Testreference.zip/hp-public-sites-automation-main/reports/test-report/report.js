$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Features/test.feature");
formatter.feature({
  "line": 1,
  "name": "Testing feature",
  "description": "",
  "id": "testing-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 6003722600,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Validate Global Nav for Care - Health Professional page",
  "description": "",
  "id": "testing-feature;validate-global-nav-for-care---health-professional-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@test"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I navigate to \"/care/for-health-professionals/\" site",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I validate \"HealthPartners home\" global nav with landing page \"Healthy\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "I validate \"About\" global nav with landing page \"About\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I validate \"Clinics \u0026 hospitals\" global nav with landing page \"Getting better, made easy\"",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I validate \"Insurance\" global nav with landing page \"Medical and dental insurance\"",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "I validate \"Pharmacy\" global nav with landing page \"Pharmacy\"",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "I validate \"Healthy Living\" global nav with landing page \"Living Well\"",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "/care/for-health-professionals/",
      "offset": 15
    }
  ],
  "location": "Test.navigateToURL(String)"
});
formatter.result({
  "duration": 3481887600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "HealthPartners home",
      "offset": 12
    },
    {
      "val": "Healthy",
      "offset": 63
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "duration": 3689801100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "About",
      "offset": 12
    },
    {
      "val": "About",
      "offset": 49
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "duration": 8643534000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Clinics \u0026 hospitals",
      "offset": 12
    },
    {
      "val": "Getting better, made easy",
      "offset": 63
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "duration": 108174600,
  "error_message": "org.openqa.selenium.UnsupportedCommandException: The test with session id bbb9bcf90d8a49b782259df241ddd0c9 has already finished, and can\u0027t receive further commands.\nFor help, please check https://wiki.saucelabs.com/display/DOCS/Common+Error+Messages\nCommand duration or timeout: 108 milliseconds\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027SPITWMGZFV6S2\u0027, ip: \u002710.20.157.81\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_201\u0027\nDriver info: org.openqa.selenium.remote.RemoteWebDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 88.0.4324.96 (68dba2d8a0b14..., userDataDir: C:\\Users\\ADMINI~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:49216}, handlesAlerts: true, hasMetadata: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), rotatable: false, setWindowRect: true, strictFileInteractability: false, takesHeapSnapshot: true, takesScreenshot: true, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unexpectedAlertBehaviour: ignore, unhandledPromptBehavior: ignore, version: 88.0.4324.104, webStorageEnabled: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true, webdriver.remote.sessionid: bbb9bcf90d8a49b782259df241d...}\nSession ID: bbb9bcf90d8a49b782259df241ddd0c9\n*** Element info: {Using\u003dclass name, value\u003dglobal-nav-menu}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:586)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByClassName(RemoteWebDriver.java:412)\r\n\tat org.openqa.selenium.By$ByClassName.findElement(By.java:389)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$7.apply(ExpectedConditions.java:205)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$7.apply(ExpectedConditions.java:201)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$22.apply(ExpectedConditions.java:641)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$22.apply(ExpectedConditions.java:638)\r\n\tat org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:249)\r\n\tat GlobalNav.GlobalNavPage.clickGlobalNavHealthPartnersDropDown(GlobalNavPage.java:26)\r\n\tat StepDefinitions.GlobalNavStepDefinition.validateGlobalNav(GlobalNavStepDefinition.java:37)\r\n\tat ✽.And I validate \"Clinics \u0026 hospitals\" global nav with landing page \"Getting better, made easy\"(Features/test.feature:8)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "Insurance",
      "offset": 12
    },
    {
      "val": "Medical and dental insurance",
      "offset": 53
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Pharmacy",
      "offset": 12
    },
    {
      "val": "Pharmacy",
      "offset": 52
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Healthy Living",
      "offset": 12
    },
    {
      "val": "Living Well",
      "offset": 58
    }
  ],
  "location": "GlobalNavStepDefinition.validateGlobalNav(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 600214536600,
  "error_message": "org.openqa.selenium.WebDriverException: \u003chtml\u003e\u003cbody\u003e\u003ch1\u003e504 Gateway Time-out\u003c/h1\u003e\nThe server didn\u0027t respond in time.\n\u003c/body\u003e\u003c/html\u003e\nCommand duration or timeout: 600.10 seconds\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027SPITWMGZFV6S2\u0027, ip: \u002710.20.157.81\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_201\u0027\nDriver info: org.openqa.selenium.remote.RemoteWebDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 88.0.4324.96 (68dba2d8a0b14..., userDataDir: C:\\Users\\ADMINI~1\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:49216}, handlesAlerts: true, hasMetadata: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), rotatable: false, setWindowRect: true, strictFileInteractability: false, takesHeapSnapshot: true, takesScreenshot: true, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unexpectedAlertBehaviour: ignore, unhandledPromptBehavior: ignore, version: 88.0.4324.104, webStorageEnabled: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true, webdriver.remote.sessionid: bbb9bcf90d8a49b782259df241d...}\nSession ID: bbb9bcf90d8a49b782259df241ddd0c9\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:586)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:609)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.quit(RemoteWebDriver.java:452)\r\n\tat StepDefinitions.Hooks.TearDown(Hooks.java:184)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.lang.reflect.Method.invoke(Method.java:498)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:37)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:13)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:31)\r\n\tat cucumber.runtime.java.JavaHookDefinition.execute(JavaHookDefinition.java:59)\r\n\tat cucumber.runtime.Runtime.runHookIfTagsMatch(Runtime.java:222)\r\n\tat cucumber.runtime.Runtime.runHooks(Runtime.java:210)\r\n\tat cucumber.runtime.Runtime.runAfterHooks(Runtime.java:204)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:50)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:91)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:238)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:63)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:236)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:53)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:229)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:309)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:93)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:37)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:238)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:63)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:236)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:53)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:229)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:309)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:98)\r\n\tat org.junit.runner.JUnitCore.run(JUnitCore.java:160)\r\n\tat com.intellij.junit4.JUnit4IdeaTestRunner.startRunnerWithArgs(JUnit4IdeaTestRunner.java:68)\r\n\tat com.intellij.rt.execution.junit.IdeaTestRunner$Repeater.startRunnerWithArgs(IdeaTestRunner.java:47)\r\n\tat com.intellij.rt.execution.junit.JUnitStarter.prepareStreamsAndStart(JUnitStarter.java:242)\r\n\tat com.intellij.rt.execution.junit.JUnitStarter.main(JUnitStarter.java:70)\r\n",
  "status": "failed"
});
formatter.uri("Features/test1.feature");
formatter.feature({
  "line": 1,
  "name": "Testing feature",
  "description": "",
  "id": "testing-feature",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Navigate to URL",
  "description": "",
  "id": "testing-feature;navigate-to-url",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@test1"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I navigate to \"/care/for-health-professionals/\" site",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I click on HealthPartners global nav dropdown",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I click on \"\u003cGlobalNavDropDownLink\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I validate \"\u003cContentPageBanner\u003e\" landing page",
  "keyword": "And "
});
formatter.examples({
  "comments": [
    {
      "line": 9,
      "value": "#Then I click on HealthPartners global nav dropdown"
    },
    {
      "line": 10,
      "value": "#And I click on \"\u003cAbout\u003e\""
    },
    {
      "line": 11,
      "value": "#And I validate \"\u003cAboutUs\u003e\" landing page"
    },
    {
      "line": 12,
      "value": "#Then I click on HealthPartners global nav dropdown"
    },
    {
      "line": 13,
      "value": "#And I click on \"Clinics \u0026 hospitals\""
    },
    {
      "line": 14,
      "value": "#And I validate \"Getting better, made easy\" landing page"
    },
    {
      "line": 15,
      "value": "#Then I click on HealthPartners global nav dropdown"
    },
    {
      "line": 16,
      "value": "#And I click on \"Insurance\""
    },
    {
      "line": 17,
      "value": "#And I validate \"Getting better, made easy\" landing page"
    }
  ],
  "line": 18,
  "name": "",
  "description": "",
  "id": "testing-feature;navigate-to-url;",
  "rows": [
    {
      "cells": [
        "GlobalNavDropDownLink",
        "ContentPageBanner"
      ],
      "line": 19,
      "id": "testing-feature;navigate-to-url;;1"
    },
    {
      "cells": [
        "HealthPartners home",
        "Healthy, made easy"
      ],
      "line": 20,
      "id": "testing-feature;navigate-to-url;;2"
    },
    {
      "cells": [
        "About",
        "About"
      ],
      "line": 21,
      "id": "testing-feature;navigate-to-url;;3"
    },
    {
      "cells": [
        "Clinics \u0026 hospitals",
        "Getting better, made easy"
      ],
      "line": 22,
      "id": "testing-feature;navigate-to-url;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 2941593500,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Navigate to URL",
  "description": "",
  "id": "testing-feature;navigate-to-url;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@test1"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I navigate to \"/care/for-health-professionals/\" site",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I click on HealthPartners global nav dropdown",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I click on \"HealthPartners home\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I validate \"Healthy, made easy\" landing page",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "/care/for-health-professionals/",
      "offset": 15
    }
  ],
  "location": "Test.navigateToURL(String)"
});
formatter.result({
  "duration": 2481118500,
  "status": "passed"
});
formatter.match({
  "location": "GlobalNavStepDefinition.clickOnHPGlobalNavDropdown()"
});
formatter.result({
  "duration": 658902900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "HealthPartners home",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.clickOnLinkText(String)"
});
formatter.result({
  "duration": 694756500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Healthy, made easy",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.validateLandingPage(String)"
});
formatter.result({
  "duration": 2357611200,
  "status": "passed"
});
formatter.after({
  "duration": 180081400,
  "status": "passed"
});
formatter.before({
  "duration": 2879776600,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Navigate to URL",
  "description": "",
  "id": "testing-feature;navigate-to-url;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@test1"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I navigate to \"/care/for-health-professionals/\" site",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I click on HealthPartners global nav dropdown",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I click on \"About\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I validate \"About\" landing page",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "/care/for-health-professionals/",
      "offset": 15
    }
  ],
  "location": "Test.navigateToURL(String)"
});
formatter.result({
  "duration": 2292303500,
  "status": "passed"
});
formatter.match({
  "location": "GlobalNavStepDefinition.clickOnHPGlobalNavDropdown()"
});
formatter.result({
  "duration": 659385600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "About",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.clickOnLinkText(String)"
});
formatter.result({
  "duration": 660867600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "About",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.validateLandingPage(String)"
});
formatter.result({
  "duration": 3630194000,
  "status": "passed"
});
formatter.after({
  "duration": 188783300,
  "status": "passed"
});
formatter.before({
  "duration": 3520895100,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Navigate to URL",
  "description": "",
  "id": "testing-feature;navigate-to-url;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@test1"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I navigate to \"/care/for-health-professionals/\" site",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "I click on HealthPartners global nav dropdown",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I click on \"Clinics \u0026 hospitals\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I validate \"Getting better, made easy\" landing page",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "/care/for-health-professionals/",
      "offset": 15
    }
  ],
  "location": "Test.navigateToURL(String)"
});
formatter.result({
  "duration": 2844892100,
  "status": "passed"
});
formatter.match({
  "location": "GlobalNavStepDefinition.clickOnHPGlobalNavDropdown()"
});
formatter.result({
  "duration": 2354312100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Clinics \u0026 hospitals",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.clickOnLinkText(String)"
});
formatter.result({
  "duration": 1568090000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Getting better, made easy",
      "offset": 12
    }
  ],
  "location": "GlobalNavStepDefinition.validateLandingPage(String)"
});
formatter.result({
  "duration": 2882313700,
  "status": "passed"
});
formatter.after({
  "duration": 255983200,
  "status": "passed"
});
});