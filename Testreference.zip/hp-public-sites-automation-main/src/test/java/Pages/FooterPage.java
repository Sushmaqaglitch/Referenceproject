package Pages;

import StepDefinitionFeatures.PageObjectBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class FooterPage extends PageObjectBase {
    private final WebDriver driver;
    private final WebDriverWait wait;

    public FooterPage(WebDriver driver) {
        super();
        this.driver = driver;
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(90));
    }

    By topFooterListItem(String columnHeading, String footerItemName) {
        return By.xpath("//*[@class='footer-column-heading'][contains(text(),'" + columnHeading + "')]//..//*[@class='footer-top-list']//..//*[contains(text(),'" + footerItemName + "')]");
    }

    By middleFooterListItem(String footerItemName) {
        return By.xpath("//div[@class='rows-sm-up']//a[contains(text(),'" + footerItemName + "')]");
    }

    By bottomFooterListItem(String footerItemName) {
        return By.xpath("//*[@class='footer-bottom-list']//..//*[contains(text(),'" + footerItemName + "')]");
    }

    public void clickTopFooterListItem(String columnHeading, String itemName) {
        waitForPageToLoad(driver, 10000, 400);
        WebElement topFooterListItemElement = wait.until(ExpectedConditions.elementToBeClickable(topFooterListItem(columnHeading, itemName)));
        topFooterListItemElement.click();
    }

    public void clickMiddleFooterListItem(String itemName) {
        waitForPageToLoad(driver, 10000, 400);
        WebElement middleFooterListItemElement = wait.until(ExpectedConditions.elementToBeClickable(middleFooterListItem(itemName)));
        middleFooterListItemElement.click();
    }

    public void clickBottomFooterListItem(String itemName) {
        waitForPageToLoad(driver, 10000, 400);
        WebElement middleFooterListItemElement = wait.until(ExpectedConditions.elementToBeClickable(bottomFooterListItem(itemName)));
        middleFooterListItemElement.click();
    }
}
