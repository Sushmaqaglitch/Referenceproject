package Pages;

import StepDefinitionFeatures.PageObjectBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BreadcrumbPage extends PageObjectBase {
    private final WebDriver driver;
    private final WebDriverWait wait;

    public BreadcrumbPage(WebDriver driver) {
        super();
        this.driver = driver;
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(90));
    }

    By breadcrumbLink(String linkText) {
        return By.xpath(".//*[@class='page-header-content-container']//a[contains(text(),'" + linkText + "')]");
    }

    public void clickBreadcrumbLink(String linkText) {
        waitForJavascriptToLoad(10000, 400);
        WebElement breadcrumbLinkTextElement = wait.until(ExpectedConditions.elementToBeClickable(breadcrumbLink(linkText)));
        breadcrumbLinkTextElement.click();
    }
}
