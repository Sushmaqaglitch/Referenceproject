package StepDefinitionFeatures;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static java.lang.Thread.sleep;

public class CommonStepDefinition extends PageObjectBase {
    final public ThreadLocal<WebDriver> driver = Hooks.driver;
    final ObjectRepository objectRepository = new ObjectRepository();
    public String siteNav;
    public String env;

    @Given("^I navigate to \"([^\"]*)\" site$")
    public void navigateToURL(String URL) throws InterruptedException {
        env = Hooks.config.getProperty("env");
        if (env.equalsIgnoreCase("prod")) {
            siteNav = Hooks.config.getProperty("prodBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("uat")) {
            siteNav = Hooks.config.getProperty("uatBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("dev")) {
            siteNav = Hooks.config.getProperty("devBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("hpuph")) {
            siteNav = Hooks.config.getProperty("hpuphBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("prodauthor")) {
            siteNav = Hooks.config.getProperty("prodauthorBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("prodaemauthoreditor")) {
            siteNav = Hooks.config.getProperty("prodaemauthoreditorUrl") + URL;
        } else if (env.equalsIgnoreCase("hpuphuatBaseUrl")) {
            siteNav = Hooks.config.getProperty("hpuphuatBaseUrl") + URL;
        } else if (env.equalsIgnoreCase("assetUrl")) {
            siteNav = Hooks.config.getProperty("assetUrl") + URL;
        }
        driver.get().navigate().to(siteNav);
        Thread.sleep(300);
    }

    @Then("^I close the current window$")
    public void i_close_the_current_window() {
        closeCurrentWindowOfheBrowser();
    }

    @Then("^I switch back to previous tab in browser$")
    public void iSwitchBackToPreviousTabInBrowser() {
        switchBackToPreviousTab();
    }

    @When("^I click on \"([^\"]*)\" cta button$")
    public void clickCtaButton(String ctaBtnText) {
        click(objectRepository.ctaButtonText(ctaBtnText));
    }

    @When("^I verify \"([^\"]*)\" cta button$")
    public void verifyCtaButton(String ctaBtnText) {
        isDisplayed(objectRepository.ctaButtonText(ctaBtnText));
    }

    @When("^I login into prod author$")
    public void loginToProdAuthor() throws InterruptedException {
        loginToProdAuthor("f8209", "March2024#");
        sleep(3000);
    }

    @When("^I verify page title \"([^\"]*)\"$")
    public void verifyPageTitle(String pageTitle) throws InterruptedException {
        sleep(300);
        Assert.assertTrue(getPageTitle().contains(pageTitle));
    }

    @When("^I verify content \"([^\"]*)\" is present on the page$")
    public void verifyContentIsPresentOnthePage(String content) {
        contentTextCount(content);
    }

    @And("^I verify body content \"([^\"]*)\" is present on the page$")
    public void verifyBodyContentIsPresentOnthePage(String content) {
        isDisplayed(objectRepository.bodyContent(content));
    }

    @When("^I verify \"([^\"]*)\" primary well is displayed on the page$")
    public void verifyPrimaryWellCountPresentOnthePage(int count) {
        Assert.assertEquals(count, primaryWellCount());
    }

    @When("^I verify media caption with video title \"([^\"]*)\" is displayed$")
    public void mediaCaptionIsDisplayed(String videoTitleText) {
        isDisplayed(objectRepository.mediaCaption(videoTitleText));
    }

    @When("^I click on \"([^\"]*)\" cta card button$")
    public void clickCtaCardButton(String ctaCardBtnText) {
        click(objectRepository.callToActionCardButtonText(ctaCardBtnText));
    }

    @When("^I click on \"([^\"]*)\" cta card$")
    public void clickCtaCard(String headingText) {
        click(objectRepository.ctaCard(headingText));
    }

    @When("^I click \"([^\"]*)\" cta card and validate \"([^\"]*)\" landing page with title \"([^\"]*)\"$")
    public void verifyCtaCard(String headingText, String landingPage, String pageTitle) {
        click(objectRepository.ctaCard(headingText));
        waitForPageLoad();
        Assert.assertTrue(getPageTitle().contains(pageTitle));
        Assert.assertTrue(getCurrentUrl().contains(landingPage));
    }

    @When("^I click \"([^\"]*)\" horizontal icon card and validate \"([^\"]*)\" landing page with title \"([^\"]*)\"$")
    public void verifyHorizontalIconCard(String headingText, String landingPage, String pageTitle) {
        click(objectRepository.iconCardHorizontal(headingText));
        waitForPageLoad();
        Assert.assertTrue(getPageTitle().contains(pageTitle));
        Assert.assertTrue(getCurrentUrl().contains(landingPage));
    }

    @When("^I click on \"([^\"]*)\" expand collapse text$")
    public void clickExpandCollapse(String expandCollapseText) {
        click(objectRepository.expandCollapse(expandCollapseText));
    }

    @When("^I click on \"([^\"]*)\" cta bar primary button$")
    public void clickCtaBarPrimaryButton(String ctaBarPrimaryBtnText) {
        click(objectRepository.callToActionBarPrimaryBtnText(ctaBarPrimaryBtnText));
    }

    @When("^I click on \"([^\"]*)\" cta bar secondary button$")
    public void clickCtaBarSecondaryButton(String ctaBarSecondaryBtnText) {
        click(objectRepository.callToActionBarSecondaryBtnText(ctaBarSecondaryBtnText));
    }

    @When("^I click on \"([^\"]*)\" hyperlink$")
    public void clickHyperLinkText(String linkText) {
        click(objectRepository.hyperLinkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" aria label$")
    public void clickAriaLabelText(String ariaLabel) {
        click(objectRepository.ariaLabelText(ariaLabel));
    }

    @When("^I click on \"([^\"]*)\" button aria label$")
    public void clickButtonAriaLabelText(String buttonText) {
        click(objectRepository.buttonAriaLabelText(buttonText));
    }

    @When("^I click on \"([^\"]*)\" checkbox$")
    public void clickCheckbox(String label) {
        click(objectRepository.checkboxLabel(label));
    }

    @When("^I enter text \"([^\"]*)\" in \"([^\"]*)\" field$")
    public void enterInputText(String randomStr, String fieldName) {
//        List<String> data = dataTable.asList(String.class);
//        System.out.println("First element -" + data.get(0));
//        System.out.println("First element -" + data.get(1));
        if (fieldName.contains("Date of birth")) {
            isDisplayed(objectRepository.datePicker());
            enterText(objectRepository.ariaLabelText(fieldName), randomStr);
        } else if (fieldName.contains("Phone")) {
            enterText(objectRepository.ariaLabelText(fieldName), getRandomNumber() + randomStr);
        } else if (fieldName.contains("City")) {
            enterText(objectRepository.ariaLabelText(fieldName), randomStr);
        } else if (fieldName.contains("Dental Insurance")) {
            enterText(objectRepository.ariaLabelText(fieldName), randomStr + " " + getRandomNumber());
        } else if (fieldName.contains("Email")) {
            enterText(objectRepository.ariaLabelText(fieldName), getRandomString() + "@gmail.com" + randomStr);
        } else {
            enterText(objectRepository.ariaLabelText(fieldName), randomStr);
        }
    }

    @When("^I enter text \"([^\"]*)\" in text area \"([^\"]*)\" field$")
    public void enterTextInTextAreaField(String randomStr, String fieldName) {
        enterText(objectRepository.textAreaAriaLabel(fieldName), randomStr);
    }

    @When("^I enter text \"([^\"]*)\" in \"([^\"]*)\" field for \"([^\"]*)\"$")
    public void enterInputText(String randomStr, String fieldName, String label) {
//        List<String> data = dataTable.asList(String.class);
//        System.out.println("First element -" + data.get(0));
//        System.out.println("First element -" + data.get(1));
        if (fieldName.contains("Date of birth") || fieldName.contains("Date")) {
            isDisplayed(objectRepository.datePicker());
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), randomStr);
        } else if (fieldName.contains("Phone")) {
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), getRandomNumber() + randomStr);
        } else if (fieldName.contains("City")) {
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), randomStr);
        } else if (fieldName.contains("Dental Insurance")) {
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), randomStr + " " + getRandomNumber());
        } else if (fieldName.contains("Email")) {
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), getRandomString() + "@gmail.com" + randomStr);
        } else {
            enterText(objectRepository.ariaLabelTextForHeader(fieldName, label), randomStr);
        }
    }

    @When("^I enter email in \"([^\"]*)\" field$")
    public void enterEmail(String fieldName) {
        enterText(objectRepository.ariaLabelText(fieldName), getRandomString() + "@gmail.com");
    }

    @When("^I select value \"([^\"]*)\" from dropdown list \"([^\"]*)\"$")
    public void selectValueFromDropdownList(String dropdownValue, String fieldName) {
        selectDropdownValueFromList(objectRepository.selectAriaLabelText(fieldName), dropdownValue);
    }

    @When("^I click on \"([^\"]*)\" hyperlink in section \"([^\"]*)\"$")
    public void clickHyperLinkTextInSection(String linkText, String section) {
        click(objectRepository.hyperLinkTextInSection(linkText, section));
    }

    @When("^I click on \"([^\"]*)\" hyperlink in accordion \"([^\"]*)\"$")
    public void clickHyperLinkTextInAccordion(String linkText, String accordion) {
        click(objectRepository.hyperLinkTextInAccordion(linkText, accordion));
    }

    @When("^I click on \"([^\"]*)\" hyperlink text basic$")
    public void clickHyperLinkTextBasic(String linkText) {
        click(objectRepository.hyperLinkTextBasic(linkText));
    }

    @When("^I click on \"([^\"]*)\" segmented control tab$")
    public void clickSegmentedControlTab(String name) {
        click(objectRepository.segmentedControlTabName(name));
    }

    @When("^I click on div \"([^\"]*)\" hyperlink$")
    public void clickDivHyperlinkText(String linkText) {
        click(objectRepository.divHyperLinkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" link text")
    public void clickLinkText(String linkText) {
        click(objectRepository.linkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" span hyperlink$")
    public void clickSpanHyperLinkText(String linkText) {
        click(objectRepository.spanHyperLinkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" sub nav$")
    public void clickSubNav(String subNav) {
        click(objectRepository.subNav(subNav));
    }

    @When("^I click on \"([^\"]*)\" tertiary hyperlink$")
    public void clickTertiaryLinkText(String linkText) {
        click(objectRepository.tertiaryLinkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" tertiary span hyperlink$")
    public void clickTertiarySpanLinkText(String linkText) {
        click(objectRepository.tertiarySpanLinkText(linkText));
    }

    @When("^I click on \"([^\"]*)\" image card$")
    public void clickImageCard(String headingText) {
        click(objectRepository.imageCard(headingText));
    }

    @When("^I click on \"([^\"]*)\" horizontal image card$")
    public void clickImageCardHorizontal(String headingText) {
        click(objectRepository.imageCardHorizontal(headingText));
    }

    @When("^I click on \"([^\"]*)\" article card$")
    public void clickArticleCard(String articleCardText) {
        click(objectRepository.articleCard(articleCardText));
    }

    @When("^I click on v3 \"([^\"]*)\" hp article card$")
    public void clickv3HpArticleCard(String articleCardText) {
        click(objectRepository.hpArticleCard(articleCardText));
    }

    @When("^I click on \"([^\"]*)\" button for \"([^\"]*)\" variable content block heading$")
    public void clickButtonForVariableContentBlockHeading(String btnText, String headingText) {
        click(objectRepository.variableContentBlockVerticalBtnText(btnText, headingText));
    }

    @When("^I click on \"([^\"]*)\" for \"([^\"]*)\" media content block$")
    public void clickLinkForMediaContentBlock(String btnText, String headingText) {
        click(objectRepository.mediaContentBlockBtnText(btnText, headingText));
    }

    @When("^I click on \"([^\"]*)\" image src$")
    public void clickImageSrc(String imageSrc) {
        click(objectRepository.imageSrc(imageSrc));
    }

    @When("^I click on \"([^\"]*)\" horizontal icon card$")
    public void clickIconCardHorizontal(String headingText) {
        click(objectRepository.iconCardHorizontal(headingText));
    }

    @When("^I click on \"([^\"]*)\" faq accordion question$")
    public void clickFaqAccordionQuestion(String questionText) {
        click(objectRepository.faqAccordion(questionText));
    }

    @When("^I click on popover icon for \"([^\"]*)\" heading$")
    public void clickPopoverIcon(String headingText) {
        click(objectRepository.popOver(headingText));
    }

    @When("^I click on popover icon for \"([^\"]*)\" section$")
    public void clickPopoverIconForSection(String section) {
        click(objectRepository.popOverForSection(section));
    }

    @When("^I click on \"([^\"]*)\" person name card$")
    public void clickPersonNameCard(String personName) {
        click(objectRepository.personNameCard(personName));
    }

    @When("^I click on \"([^\"]*)\" heading$")
    public void clickHeadingText(String headingText) {
        click(objectRepository.headerText(headingText));
    }

    @When("^I click on doctors loading page$")
    public void clickDoctorsLoadingPage() throws InterruptedException {
        sleep(2000);
        click(objectRepository.doctorsLoadingPage);
    }

    @When("^I click on \"([^\"]*)\" text content$")
    public void clickTextContent(String text) {
        click(objectRepository.textContent(text));
    }

    @When("^I click on \"([^\"]*)\" span hyper link under \"([^\"]*)\" button name$")
    public void clickSpanHyperLinkUnderButtonName(String hyperLink, String buttonName) {
        click(objectRepository.buttonName(buttonName));
        click(objectRepository.spanHyperLinkText(hyperLink));
    }

    @When("^I verify page notification is displayed$")
    public void pageNotficationIsDisplayed() {
        isDisplayed(objectRepository.notification);
    }

    @When("^I verify \"([^\"]*)\" hyperlink is displayed$")
    public void verifyHyperLinkText(String linkText) {
        isDisplayed(objectRepository.hyperLinkText(linkText));
    }

    @When("^I verify \"([^\"]*)\" link text is displayed$")
    public void verifyLinkText(String text) {
        isDisplayed(objectRepository.linkText(text));
    }

    @When("^I verify \"([^\"]*)\" nav link is displayed$")
    public void verifyNavLink(String navLink) {
        isDisplayed(objectRepository.siteNavLink(navLink));
    }

    @When("^I verify \"([^\"]*)\" is an external link$")
    public void verifyExternalLink(String externalLinkText) {
        isDisplayed(objectRepository.externalLink(externalLinkText));
    }

    @When("^I verify \"([^\"]*)\" label is displayed$")
    public void verifyLabelText(String label) {
        isDisplayed(objectRepository.labelText(label));
    }

    @When("^I verify hours \"([^\"]*)\" on \"([^\"]*)\" day is displayed$")
    public void verifyHoursOnADayIsDisplayed(String hours, String day) {
        isDisplayed(objectRepository.regularHoursDay(hours, day));
    }

    @When("^I verify urgent care hours \"([^\"]*)\" on \"([^\"]*)\" day is displayed$")
    public void verifyUrgentCareHoursOnADayIsDisplayed(String hours, String day) {
        click(objectRepository.spanHyperLinkText("Show hours"));
        isDisplayed(objectRepository.regularHoursDay(hours, day));
    }

    @When("^I verify \"([^\"]*)\" icon name is displayed$")
    public void verifyIconNameIsDisplayed(String name) {
        isDisplayed(objectRepository.iconName(name));
    }

    @When("^I verify \"([^\"]*)\" footer link with href \"([^\"]*)\" is displayed$")
    public void verifyFooterLinkWithHrefIsDisplayed(String linkText, String href) {
        isDisplayed(objectRepository.footerhref(linkText, href));
    }

    @When("^I verify \"([^\"]*)\" link with href \"([^\"]*)\" is displayed$")
    public void verifyLinkWithHrefIsDisplayed(String linkText, String href) {
        isDisplayed(objectRepository.href(linkText, href));
    }

    @When("^I verify \"([^\"]*)\" href for \"([^\"]*)\" span link is displayed$")
    public void verifySpanLinkWithHrefIsDisplayed(String href, String linkText) {
        isDisplayed(objectRepository.spanLinkhref(href, linkText));
    }

    @When("^I verify \"([^\"]*)\" href is displayed$")
    public void verifyHrefIsDisplayed(String href) {
        isDisplayed(objectRepository.hrefLink(href));
    }


    @When("^I verify \"([^\"]*)\" cta bar primary button is displayed$")
    public void verifyCtaBarPrimaryBtnIsDisplayed(String btnText) {
        isDisplayed(objectRepository.callToActionBarPrimaryBtnText(btnText));
    }

    @When("^I verify \"([^\"]*)\" cta secondary button is displayed$")
    public void verifyCtaSecondaryBtnIsDisplayed(String btnText) {
        isDisplayed(objectRepository.callToActionBarSecondaryBtnText(btnText));
    }

    @When("^I verify doctor geosearch is displayed$")
    public void verifyDoctorGeoSearchIsDisplayed() {
        isDisplayed(objectRepository.doctorGeoSearch);
    }

    @When("^I verify alert is displayed$")
    public void alertIsDisplayed() {
        isDisplayed(objectRepository.alert);
    }

    @When("^I verify \"([^\"]*)\" cta primary button is displayed$")
    public void verifyCtaPrimaryButtonIsDisplayed(String btnText) {
        isDisplayed(objectRepository.callToActionPrimary(btnText));
    }

    @When("^I verify primary well is displayed$")
    public void primaryWellIsDisplayed() {
        isDisplayed(objectRepository.primaryWell);
    }

    @When("^I verify \"([^\"]*)\" cta card is displayed$")
    public void verifyCtaCardIsDisplayed(String headingText) {
        isDisplayed(objectRepository.ctaCard(headingText));
    }

    @When("^I verify \"([^\"]*)\" cta text is displayed$")
    public void verifyCtaTextIsDisplayed(String ctaText) {
        isDisplayed(objectRepository.ctaText(ctaText));
    }

    @When("^I verify c0 background image is displayed$")
    public void c0BackgroundImageIsDisplayed() {
        isDisplayed(objectRepository.c0BackgroundImage);
    }

    @And("^I verify c3 text container no image banner text \"([^\"]*)\" is displayed$")
    public void c3TextContainerNoImageBannerIsDisplayed(String bannerText) {
        isDisplayed(objectRepository.c3TextContainerNoImage(bannerText));
    }

    @And("^I verify c0 heading text \"([^\"]*)\" is displayed$")
    public void c0HeadingTextIsDisplayed(String headingText) {
        isDisplayed(objectRepository.c0HeadingText(headingText));
    }

    @And("^I verify button text \"([^\"]*)\" is displayed$")
    public void buttonTextIsDisplayed(String buttonText) {
        isDisplayed(objectRepository.buttonText(buttonText));
    }

    @And("^I verify span hyperlink \"([^\"]*)\" is displayed$")
    public void spanHyperLinkIsDisplayed(String linkText) {
        isDisplayed(objectRepository.spanHyperLinkText(linkText));
    }

    @And("^I verify paragraph text \"([^\"]*)\" is displayed$")
    public void paragraphIsDisplayed(String text) {
        isDisplayed(objectRepository.paragraph(text));
    }

    @And("^I verify error message \"([^\"]*)\" displayed for \"([^\"]*)\" field name$")
    public void errorMessageIsDisplayed(String errorMessage, String fieldName) {
        isDisplayed(objectRepository.fieldErrorMessage(errorMessage, fieldName));
    }

    @And("^I verify nav option \"([^\"]*)\" is displayed$")
    public void navOptionIsDisplayed(String nav) {
        isDisplayed(objectRepository.navOption(nav));
    }

    @And("^I verify \"([^\"]*)\" div hyperlink is displayed$")
    public void divHyperlinkTextIsDisplayed(String text) {
        isDisplayed(objectRepository.divHyperLinkText(text));
    }

    @And("^I verify quote content \"([^\"]*)\" is displayed$")
    public void quoteContentTextIsDisplayed(String quote) {
        isDisplayed(objectRepository.quoteContent(quote));
    }

    @And("^I verify tooltip content \"([^\"]*)\" is displayed$")
    public void tooltipContentIsDisplayed(String text) {
        isDisplayed(objectRepository.tooltipContentText(text));
    }

    @And("^I verify \"([^\"]*)\" icon is displayed$")
    public void iconIsDisplayed(String name) {
        isDisplayed(objectRepository.iconName(name));
    }

    @And("^I verify \"([^\"]*)\" social media is displayed$")
    public void socialMediaIsDisplayed(String name) {
        isDisplayed(objectRepository.socialMediaList(name));
    }

    @And("^I verify \"([^\"]*)\" v3 social media icon is displayed$")
    public void v3SocialMediaIconIsDisplayed(String name) {
        isDisplayed(objectRepository.v3socialMediaIcon(name));
    }

    @And("^I verify c2 background image heading text \"([^\"]*)\" is displayed$")
    public void c2BackgroundImageHeadingText(String headingText) {
        isDisplayed(objectRepository.c2BackgroundImageHeadingText(headingText));
    }

    @And("^I verify feature story heading text \"([^\"]*)\" is displayed$")
    public void featureStoryHeadingText(String headingText) {
        isDisplayed(objectRepository.featureStoryHeadingText(headingText));
    }

    @And("^I verify image src \"([^\"]*)\" is displayed$")
    public void imageSrcIsDisplayed(String imageSrc) {
        isDisplayed(objectRepository.imageSrcPath(imageSrc));
    }

    @And("^I verify src \"([^\"]*)\" is displayed$")
    public void srcIsDisplayed(String src) {
        isDisplayed(objectRepository.srcPath(src));
    }

    @And("^I verify video src \"([^\"]*)\" is displayed$")
    public void videoSrcIsDisplayed(String src) {
        isDisplayed(objectRepository.videoSrcPath(src));
    }

    @And("^I verify \"([^\"]*)\" call to action bar is displayed$")
    public void callToActionBarIsDisplayed(String ctaBarText) {
        isDisplayed(objectRepository.callToActionBarText(ctaBarText));
    }


    @And("^I verify c2 background image is displayed$")
    public void c2BackgroundImageIsDisplayed() {
        isDisplayed(objectRepository.c2BackgroundImageText);
    }

    @And("^I verify sub nav title \"([^\"]*)\" is displayed$")
    public void subNavTitleText(String titleText) {
        isDisplayed(objectRepository.subNavTitle(titleText));
    }

    @And("^I verify sub nav items \"([^\"]*)\" are displayed$")
    public void subNavItem(String itemText) {
        String[] items = itemText.split(",");
        for (String item : items) {
            isDisplayed(objectRepository.subNavItem(item));
        }
    }

//    @And("^I verify sub nav item \"([^\"]*)\" is displayed$")
//    public void subNavItem(List<DataTable> dataTable, List<String> itemText) {
//        for (int i=0; i < dataTable.size(); i++){
//            DataTable aDataTable = dataTable.get(i);
//            aDataTable.item
//        }
//        isDisplayed(objectRepository.subNavItem(itemText));
//    }

    @And("^I verify h1 header text \"([^\"]*)\" is displayed$")
    public void headerTextIsDisplayed(String titleText) {
        isDisplayed(objectRepository.headerText(titleText));
    }

    @And("^I verify media content block text \"([^\"]*)\" is displayed$")
    public void mediaContentBlockText(String blockText) {
        isDisplayed(objectRepository.mediaContentBlockText(blockText));
    }

    @And("^I verify media content block \"([^\"]*)\" text with \"([^\"]*)\" and click link \"([^\"]*)\" to validate \"([^\"]*)\" landing page with title \"([^\"]*)\"$")
    public void verifyMediaContentBlock(String blockText, String imageSrc, String link, String landingPage, String pageTitle) {
        isDisplayed(objectRepository.mediaContentBlockText(blockText));
        if (!imageSrc.isEmpty()) {
            isDisplayed(objectRepository.imageSrc(imageSrc));
        } else throw new RuntimeException();
        if (!link.isEmpty()) {
            click(objectRepository.spanHyperLinkText(link));
            waitForPageLoad();
            Assert.assertTrue(getPageTitle().contains(pageTitle));
            Assert.assertTrue(getCurrentUrl().contains(landingPage));
        } else throw new RuntimeException();
    }

    @And("^I verify variable content block horizontal text \"([^\"]*)\" is displayed$")
    public void variableContentBlockHorizontalText(String blockText) {
        isDisplayed(objectRepository.variableContentBlockHorizontalText(blockText));
    }

    @And("^I verify variable content block vertical text \"([^\"]*)\" is displayed$")
    public void variableContentBlockVerticalText(String blockText) {
        isDisplayed(objectRepository.variableContentBlockVerticalText(blockText));
    }

    @And("^I verify text \"([^\"]*)\" is present$")
    public void textIsPresent(String text) {
        isDisplayed(objectRepository.textElement(text));
    }

    @And("^I verify mini sites heading section content \"([^\"]*)\" is displayed$")
    public void headingMiniSitesSectionContentIsDisplayed(String heading) {
        isDisplayed(objectRepository.headingSectionMiniSites(heading));
    }

    @And("^I verify heading section content \"([^\"]*)\" is displayed$")
    public void headingSectionContentIsDisplayed(String heading) {
        isDisplayed(objectRepository.headingSection(heading));
    }

    @And("^I scroll up$")
    public void scrollUp() throws InterruptedException {
        scroll();
    }

    @And("^I scroll to doctor feed mini app element$")
    public void scrollToElement() {
        WebElement element = driver.get().findElement(objectRepository.doctorsLoadingPage);
        scrollElementIntoView(element);
    }
}
