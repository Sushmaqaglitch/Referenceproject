/*
package StepDefinitionFeatures;

import org.openqa.selenium.WebDriver;
import org.apache.log4j.Logger;

import java.util.concurrent.TimeUnit;

public class DriverManager {
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
    static Logger log;

    static {
        log = Logger.getLogger(DriverManager.class);
    }

    public static WebDriver getDriver(){
        if (driver.get() == null){
            log.info("Thread has no WebDriver, creating new one");
            setWebDriver(LocalDriverFactory.createInstance(null));
        }
        log.debug("Getting instance of remote driver" +driver.get().getClass());
        return driver.get();
    }

    public static void setWebDriver(WebDriver driver){
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        DriverManager.driver.set(driver);
    }
}
*/
