package StepDefinitionFeatures;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(
        features = {"@target/cucumber-reports/rerun.txt"},
        //glue = {"StepDefinitionFeatures"},
        //tags = "@tria",
        monochrome = true,
        plugin = {
                "pretty",
                "html:targetrerun/cucumber-reports/report.html",
                "json:targetrerun/cucumber-reports/cucumber.json",
                "rerun:targetrerun/cucumber-reports/runnerrerun.txt"
        }
)

public class TestRunnerRerun extends AbstractTestNGCucumberTests {
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
