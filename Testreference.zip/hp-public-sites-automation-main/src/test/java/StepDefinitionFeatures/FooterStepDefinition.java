package StepDefinitionFeatures;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class FooterStepDefinition extends PageObjectBase {
    public final ThreadLocal<WebDriver> driver = Hooks.driver;
    final ObjectRepository objectRepository = new ObjectRepository();

    @When("^I click on \"([^\"]*)\" footer link under \"([^\"]*)\" footer column$")
    public void clickFooterLink(String footerLinkItem, String columnHeading) {
        click(objectRepository.topFooterListItem(columnHeading, footerLinkItem));
    }

    @When("^I click on \"([^\"]*)\" footer link under language assistance$")
    public void clickLanguageFooterLink(String footerLinkItem) {
        click(objectRepository.middleFooterListItem(footerLinkItem));
    }

    @When("^I click on \"([^\"]*)\" bottom footer link$")
    public void clickBottomFooterLink(String footerLinkItem) {
        click(objectRepository.bottomFooterListItem(footerLinkItem));
    }

    @And("^I verify \"([^\"]*)\" bottom footer list item$")
    public void verifyBottomFooterListItem(String itemName) {
        isDisplayed(objectRepository.bottomFooterListItem(itemName));
    }

    @And("^I validate language assistance pdf$")
    public void validateLanguageAssistancePdf() {
        isDisplayed(objectRepository.embedPdf);
    }

    @And("^I verify top footer$")
    public void verifyTopFooter() {
        isDisplayed(objectRepository.topFooter);
    }

    @And("^I verify top footer for oracle page$")
    public void verifyTopFooterForOraclePage() {
        isDisplayed(objectRepository.oracleTopFooter);
    }

    @And("^I verify middle footer$")
    public void verifyMiddleFooter() {
        isDisplayed(objectRepository.middleFooter);
    }

    @And("^I verify middle footer for oracle page$")
    public void verifyMiddleFooterForOraclePage() {
        isDisplayed(objectRepository.oracleMiddleFooter);
    }

    @And("^I verify bottom footer$")
    public void verifyBottomFooter() {
        isDisplayed(objectRepository.bottomFooter);
    }

    @And("^I verify bottom footer for oracle page$")
    public void verifyBottomFooterForOraclePage() {
        isDisplayed(objectRepository.oracleBottomFooter);
    }

    @And("^I verify chat bubble$")
    public void verifyChatBubble() {
        isDisplayed(objectRepository.chatBubble);
    }
}
